<?php
/**
 * Plugin Name: Video Translator & Dubbing
 * Plugin URI: https://example.com/video-translator
 * Description: مترجم ومدبلج فيديوهات يوتيوب. يتيح للمستخدمين ترجمة ودبلجة فيديوهات يوتيوب إلى لغات متعددة.
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://example.com
 * Text Domain: video-translator
 * Domain Path: /languages
 * Requires at least: 5.6
 * Requires PHP: 7.4
 */

// منع الوصول المباشر
if (!defined('ABSPATH')) {
    exit;
}

// تعريف ثوابت الإضافة
define('VT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('VT_PLUGIN_URL', plugin_dir_url(__FILE__));
define('VT_PLUGIN_VERSION', '1.0.0');
define('VT_TEMP_DIR', wp_upload_dir()['basedir'] . '/video-translator-temp');

// تضمين الملفات الضرورية
require_once VT_PLUGIN_DIR . 'includes/class-video-translator.php';
require_once VT_PLUGIN_DIR . 'includes/class-video-translator-admin.php';
require_once VT_PLUGIN_DIR . 'includes/class-video-translator-shortcodes.php';
require_once VT_PLUGIN_DIR . 'includes/class-video-translator-subscriptions.php';
require_once VT_PLUGIN_DIR . 'includes/class-video-translator-user-profile.php';

/**
 * بدء تشغيل الإضافة
 */
function vt_init() {
    // إنشاء المجلد المؤقت إذا لم يكن موجوداً
    if (!file_exists(VT_TEMP_DIR)) {
        wp_mkdir_p(VT_TEMP_DIR);
    }
    
    // تهيئة الكلاسات الرئيسية
    $video_translator = new Video_Translator();
    $video_translator_admin = new Video_Translator_Admin();
    $video_translator_shortcodes = new Video_Translator_Shortcodes();
    
    // تسجيل الأحداث
    register_activation_hook(__FILE__, 'vt_activate');
    register_deactivation_hook(__FILE__, 'vt_deactivate');
}
add_action('plugins_loaded', 'vt_init');

/**
 * تنفيذ عند تفعيل الإضافة
 */
function vt_activate() {
    // إنشاء المجلد المؤقت
    if (!file_exists(VT_TEMP_DIR)) {
        wp_mkdir_p(VT_TEMP_DIR);
    }
    
    // إضافة إعدادات افتراضية
    $default_options = array(
        'deepl_api_key' => '',
        'elevenlabs_api_key' => '',
        'default_language' => 'ar',
        'max_upload_size' => 20, // بالميجابايت
        'enable_youtube' => 'yes',
        'enable_upload' => 'yes',
        'delete_temp_files' => 'yes',
        'enable_subscription' => 'yes', // تفعيل نظام الاشتراكات افتراضياً
        'enable_free_tier' => 'yes', // تفعيل الطبقة المجانية
        'free_videos_limit' => 3, // عدد الفيديوهات المجانية الافتراضي
        'free_duration_limit' => 5, // حد المدة للفيديوهات المجانية (دقائق)
    );
    
    add_option('vt_settings', $default_options);
    
    // إضافة أدوار المستخدمين
    // المشترك العادي
    add_role('vt_subscriber', __('مشترك مترجم الفيديو', 'video-translator'), array(
        'read' => true,
        'vt_use_youtube' => true,
        'vt_upload_videos' => true,
    ));
    
    // المشترك المتميز
    add_role('vt_premium_subscriber', __('مشترك متميز في مترجم الفيديو', 'video-translator'), array(
        'read' => true,
        'vt_use_youtube' => true,
        'vt_upload_videos' => true,
        'vt_use_elevenlabs' => true,
        'vt_use_lip_sync' => true,
    ));
    
    // إضافة قدرات للأدوار الموجودة
    $admin_role = get_role('administrator');
    $admin_role->add_cap('vt_manage_settings');
    $admin_role->add_cap('vt_manage_subscriptions');
    $admin_role->add_cap('vt_use_youtube');
    $admin_role->add_cap('vt_upload_videos');
    $admin_role->add_cap('vt_use_elevenlabs');
    $admin_role->add_cap('vt_use_lip_sync');
    
    // إعداد خطط الاشتراك الافتراضية
    $subscription_plans = get_option('vt_subscription_plans', array());
    
    // إضافة الخطط الافتراضية فقط إذا لم تكن موجودة
    if (empty($subscription_plans)) {
        $default_plans = array(
            'free' => array(
                'name' => __('باقة مجانية', 'video-translator'),
                'price' => 0,
                'duration' => 'unlimited',
                'max_videos' => 3,
                'max_duration' => 5, // 5 دقائق
                'features' => array('youtube_support', 'upload_support'),
                'status' => 'active',
                'woo_product_id' => 0,
            ),
            'basic' => array(
                'name' => __('باقة أساسية', 'video-translator'),
                'price' => 9.99,
                'duration' => 'month',
                'max_videos' => 15,
                'max_duration' => 15, // 15 دقيقة
                'features' => array('youtube_support', 'upload_support', 'download_video'),
                'status' => 'active',
                'woo_product_id' => 0,
            ),
            'premium' => array(
                'name' => __('باقة متميزة', 'video-translator'),
                'price' => 19.99,
                'duration' => 'month',
                'max_videos' => -1, // غير محدود
                'max_duration' => 30, // 30 دقيقة
                'features' => array('youtube_support', 'upload_support', 'elevenlabs_voices', 'download_video'),
                'status' => 'active',
                'woo_product_id' => 0,
            ),
            'professional' => array(
                'name' => __('باقة احترافية', 'video-translator'),
                'price' => 39.99,
                'duration' => 'month',
                'max_videos' => -1, // غير محدود
                'max_duration' => -1, // غير محدود
                'features' => array('youtube_support', 'upload_support', 'elevenlabs_voices', 'lip_sync', 'download_video'),
                'status' => 'active',
                'woo_product_id' => 0,
            ),
        );
        
        update_option('vt_subscription_plans', $default_plans);
    }
    
    // تشغيل حدث مخصص لإعداد الاشتراكات
    do_action('vt_activate');
}

/**
 * تنفيذ عند إلغاء تفعيل الإضافة
 */
function vt_deactivate() {
    // حذف المجلد المؤقت إذا كان مطلوباً
    if (get_option('vt_settings')['delete_temp_files'] === 'yes') {
        vt_rmdir_recursive(VT_TEMP_DIR);
    }
}

/**
 * تنفيذ عند حذف الإضافة
 */
function vt_uninstall() {
    // حذف الإعدادات
    delete_option('vt_settings');
    delete_option('vt_subscription_plans');
    delete_option('vt_subscription_logs');
    
    // حذف المجلد المؤقت
    vt_rmdir_recursive(VT_TEMP_DIR);
    
    // حذف الأدوار المخصصة
    remove_role('vt_subscriber');
    remove_role('vt_premium_subscriber');
    
    // حذف البيانات الوصفية للمستخدمين
    global $wpdb;
    $wpdb->delete($wpdb->usermeta, array('meta_key' => 'vt_subscription'));
    $wpdb->delete($wpdb->usermeta, array('meta_key' => 'vt_usage_history'));
}
register_uninstall_hook(__FILE__, 'vt_uninstall');

/**
 * حذف مجلد بشكل متكرر
 */
function vt_rmdir_recursive($dir) {
    if (is_dir($dir)) {
        $objects = scandir($dir);
        foreach ($objects as $object) {
            if ($object != "." && $object != "..") {
                if (is_dir($dir . "/" . $object)) {
                    vt_rmdir_recursive($dir . "/" . $object);
                } else {
                    unlink($dir . "/" . $object);
                }
            }
        }
        rmdir($dir);
    }
}

/**
 * دالة للتحقق من المتطلبات
 */
function vt_check_requirements() {
    $errors = array();
    
    // التحقق من إصدار PHP
    if (version_compare(PHP_VERSION, '7.4', '<')) {
        $errors[] = sprintf(
            __('Video Translator requires PHP version 7.4 or higher. Your current version is %s.', 'video-translator'),
            PHP_VERSION
        );
    }
    
    // التحقق من وجود ffmpeg
    $ffmpeg_path = exec('which ffmpeg');
    if (empty($ffmpeg_path)) {
        $errors[] = __('Video Translator requires ffmpeg to be installed on the server.', 'video-translator');
    }
    
    // التحقق من وجود python
    $python_path = exec('which python3');
    if (empty($python_path)) {
        $errors[] = __('Video Translator requires Python 3 to be installed on the server.', 'video-translator');
    }
    
    // إذا كانت هناك أخطاء، أظهرها وقم بتعطيل الإضافة
    if (!empty($errors)) {
        // تعطيل الإضافة
        deactivate_plugins(plugin_basename(__FILE__));
        
        // إظهار الأخطاء
        $message = '<div class="error">';
        $message .= '<p>' . __('Video Translator has been deactivated due to the following requirements not being met:', 'video-translator') . '</p>';
        $message .= '<ul>';
        foreach ($errors as $error) {
            $message .= '<li>' . $error . '</li>';
        }
        $message .= '</ul>';
        $message .= '</div>';
        
        echo $message;
        
        // إيقاف الهوكات
        remove_action('admin_notices', 'vt_check_requirements');
        return false;
    }
    
    return true;
}
add_action('admin_notices', 'vt_check_requirements');