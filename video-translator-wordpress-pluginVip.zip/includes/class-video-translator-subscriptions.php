<?php
/**
 * فئة إدارة الاشتراكات
 */
class Video_Translator_Subscriptions {
    /**
     * إعداد الحدث
     */
    public function __construct() {
        // إضافة نوع منشور مخصص لخطط الاشتراك
        add_action('init', array($this, 'register_post_types'));
        
        // إضافة وسوم العرض المختصرة (shortcodes)
        add_shortcode('video_translator_payment', array($this, 'payment_page_shortcode'));
        add_shortcode('video_translator_plans', array($this, 'plans_shortcode'));
        
        // إعداد المشغلات لمعالجة المدفوعات
        add_action('wp_ajax_vt_purchase_subscription', array($this, 'handle_subscription_purchase'));
        add_action('wp_ajax_nopriv_vt_purchase_subscription', array($this, 'handle_subscription_purchase'));
        
        // إضافة الهوكات للتحقق من صلاحية الاشتراك
        add_filter('vt_can_use_feature', array($this, 'check_feature_access'), 10, 2);
        
        // إضافة أحداث معالجة البيانات
        add_action('wp_ajax_vt_get_subscription_plan', array($this, 'get_subscription_plan_ajax'));
        
        // إعداد مزامنة مع WooCommerce إذا كان متاحاً
        if ($this->is_woocommerce_active()) {
            add_action('woocommerce_order_status_completed', array($this, 'process_woocommerce_order'), 10, 1);
            add_action('woocommerce_subscription_status_active', array($this, 'process_woocommerce_subscription'), 10, 1);
            add_action('woocommerce_subscription_status_cancelled', array($this, 'cancel_woocommerce_subscription'), 10, 1);
        }
        
        // إعداد الكرون جوب لإزالة الاشتراكات المنتهية
        if (!wp_next_scheduled('vt_check_expired_subscriptions')) {
            wp_schedule_event(time(), 'daily', 'vt_check_expired_subscriptions');
        }
        add_action('vt_check_expired_subscriptions', array($this, 'check_expired_subscriptions'));
        
        // تسجيل وحدة Elementor إذا كانت متاحة
        add_action('elementor/widgets/widgets_registered', array($this, 'register_elementor_widgets'));
    }
    
    /**
     * إضافة أنواع المنشورات المخصصة
     */
    public function register_post_types() {
        /*
        // هذا القسم تم تعليقه لنستخدم الآن التخزين في خيارات الموقع بدلاً من أنواع المنشورات
        // في تحديث لاحق يمكن استخدام أنواع المنشورات إذا كانت هناك حاجة لخيارات أكثر تقدماً
        
        register_post_type('vt_subscription_plan', array(
            'labels' => array(
                'name' => __('خطط الاشتراك', 'video-translator'),
                'singular_name' => __('خطة اشتراك', 'video-translator'),
                'add_new' => __('إضافة خطة جديدة', 'video-translator'),
                'add_new_item' => __('إضافة خطة اشتراك جديدة', 'video-translator'),
                'edit_item' => __('تعديل خطة اشتراك', 'video-translator'),
                'new_item' => __('خطة اشتراك جديدة', 'video-translator'),
                'view_item' => __('عرض خطة الاشتراك', 'video-translator'),
                'search_items' => __('بحث في خطط الاشتراك', 'video-translator'),
                'not_found' => __('لم يتم العثور على خطط اشتراك', 'video-translator'),
                'not_found_in_trash' => __('لا توجد خطط اشتراك في سلة المهملات', 'video-translator'),
                'menu_name' => __('خطط الاشتراك', 'video-translator'),
            ),
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => 'video-translator',
            'supports' => array('title', 'editor', 'custom-fields'),
            'capability_type' => 'post',
            'capabilities' => array(
                'create_posts' => 'vt_manage_subscriptions',
                'edit_post' => 'vt_manage_subscriptions',
                'edit_posts' => 'vt_manage_subscriptions',
                'edit_others_posts' => 'vt_manage_subscriptions',
                'publish_posts' => 'vt_manage_subscriptions',
                'read_post' => 'vt_manage_subscriptions',
                'read_private_posts' => 'vt_manage_subscriptions',
                'delete_post' => 'vt_manage_subscriptions',
            ),
            'map_meta_cap' => true,
        ));
        */
    }
    
    /**
     * التحقق مما إذا كانت إضافة WooCommerce نشطة
     *
     * @return bool
     */
    public function is_woocommerce_active() {
        return class_exists('WooCommerce');
    }
    
    /**
     * التحقق من الاشتراكات المنتهية
     */
    public function check_expired_subscriptions() {
        $users = get_users(array(
            'meta_key' => 'vt_subscription',
            'meta_compare' => 'EXISTS',
        ));
        
        $now = time();
        
        foreach ($users as $user) {
            $subscription = get_user_meta($user->ID, 'vt_subscription', true);
            
            // التحقق فقط من الاشتراكات غير المحدودة المدة
            if (!empty($subscription) && isset($subscription['expiry']) && $subscription['expiry'] !== -1) {
                // إذا انتهى الاشتراك
                if ($subscription['expiry'] < $now) {
                    // تسجيل إلغاء الاشتراك
                    $this->log_subscription_event($user->ID, 'expired', $subscription['plan_id']);
                    
                    // إزالة الاشتراك وإعادة المستخدم إلى الوضع العادي
                    delete_user_meta($user->ID, 'vt_subscription');
                    
                    // إزالة الأدوار المتعلقة بالاشتراك
                    $user_obj = new WP_User($user->ID);
                    $user_obj->remove_role('vt_subscriber');
                    $user_obj->remove_role('vt_premium_subscriber');
                    
                    // إرسال إشعار للمستخدم (اختياري)
                    $this->send_subscription_expiry_notification($user->ID);
                }
            }
        }
    }
    
    /**
     * إرسال إشعار بانتهاء الاشتراك
     *
     * @param int $user_id معرف المستخدم
     */
    public function send_subscription_expiry_notification($user_id) {
        $user = get_userdata($user_id);
        
        if ($user) {
            $subject = __('انتهاء اشتراكك في مترجم الفيديو', 'video-translator');
            
            $message = __('عزيزي', 'video-translator') . ' ' . $user->display_name . ",\n\n";
            $message .= __('نود إعلامك أن اشتراكك في خدمة مترجم الفيديو قد انتهى.', 'video-translator') . "\n";
            $message .= __('إذا كنت ترغب في الاستمرار في استخدام الخدمة، يرجى تجديد اشتراكك.', 'video-translator') . "\n\n";
            $message .= __('مع خالص التقدير،', 'video-translator') . "\n";
            $message .= get_bloginfo('name');
            
            wp_mail($user->user_email, $subject, $message);
        }
    }
    
    /**
     * التحقق من صلاحية الوصول للميزات
     *
     * @param bool $can_use ما إذا كان المستخدم يمكنه استخدام الميزة
     * @param string $feature الميزة التي يتم التحقق منها
     * @return bool
     */
    public function check_feature_access($can_use, $feature) {
        // تخطي التحقق للمدراء
        if (current_user_can('administrator')) {
            return true;
        }
        
        // الحصول على إعدادات الاشتراك
        $settings = get_option('vt_settings', array());
        $enable_subscription = isset($settings['enable_subscription']) ? $settings['enable_subscription'] : 'yes';
        
        // إذا كان نظام الاشتراكات معطل، السماح بالوصول للجميع
        if ($enable_subscription !== 'yes') {
            return true;
        }
        
        // الحصول على الميزات المدفوعة من الإعدادات
        $premium_features = isset($settings['premium_features']) ? (array) $settings['premium_features'] : array();
        
        // إذا لم تكن الميزة مدفوعة، السماح بالوصول
        if (!in_array($feature, $premium_features)) {
            return true;
        }
        
        // التحقق مما إذا كان المستخدم مسجلاً
        if (!is_user_logged_in()) {
            return false;
        }
        
        // الحصول على بيانات المستخدم
        $user_id = get_current_user_id();
        $subscription = get_user_meta($user_id, 'vt_subscription', true);
        
        // التحقق من وجود اشتراك نشط
        if (empty($subscription)) {
            // التحقق من تفعيل الطبقة المجانية
            $enable_free_tier = isset($settings['enable_free_tier']) ? $settings['enable_free_tier'] : 'yes';
            
            if ($enable_free_tier === 'yes') {
                // الحصول على تاريخ استخدام المستخدم
                $usage_history = get_user_meta($user_id, 'vt_usage_history', true);
                
                if (empty($usage_history)) {
                    $usage_history = array(
                        'videos_processed' => 0,
                    );
                }
                
                // التحقق من عدد الفيديوهات المعالجة
                $free_videos_limit = isset($settings['free_videos_limit']) ? intval($settings['free_videos_limit']) : 3;
                
                if ($usage_history['videos_processed'] < $free_videos_limit) {
                    return true;
                }
            }
            
            return false;
        }
        
        // التحقق من تاريخ انتهاء الاشتراك
        if ($subscription['expiry'] !== -1 && $subscription['expiry'] < time()) {
            return false;
        }
        
        // التحقق من عدد الفيديوهات المتبقية
        if (isset($subscription['videos_left']) && $subscription['videos_left'] !== -1 && $subscription['videos_left'] <= 0) {
            return false;
        }
        
        // التحقق من الميزات المتاحة في الاشتراك
        if (!isset($subscription['features']) || !in_array($feature, $subscription['features'])) {
            return false;
        }
        
        return true;
    }
    
    /**
     * الحصول على خطط الاشتراك المتاحة
     *
     * @param bool $active_only جلب الخطط النشطة فقط
     * @return array
     */
    public function get_subscription_plans($active_only = true) {
        $plans = get_option('vt_subscription_plans', array());
        
        if ($active_only) {
            foreach ($plans as $key => $plan) {
                if (!isset($plan['status']) || $plan['status'] !== 'active') {
                    unset($plans[$key]);
                }
            }
        }
        
        return $plans;
    }
    
    /**
     * الحصول على خطة اشتراك محددة
     *
     * @param string $plan_id معرف الخطة
     * @return array|null
     */
    public function get_subscription_plan($plan_id) {
        $plans = get_option('vt_subscription_plans', array());
        
        if (isset($plans[$plan_id])) {
            return $plans[$plan_id];
        }
        
        return null;
    }
    
    /**
     * الحصول على خطة اشتراك عبر AJAX
     */
    public function get_subscription_plan_ajax() {
        // التحقق من الأمان
        check_ajax_referer('vt_get_subscription_plan', 'nonce');
        
        // التحقق من البيانات المستلمة
        if (!isset($_POST['plan_id'])) {
            wp_send_json_error(array('message' => __('لم يتم تحديد خطة الاشتراك', 'video-translator')));
        }
        
        $plan_id = sanitize_text_field($_POST['plan_id']);
        $plan = $this->get_subscription_plan($plan_id);
        
        if (!$plan) {
            wp_send_json_error(array('message' => __('خطة الاشتراك غير موجودة', 'video-translator')));
        }
        
        wp_send_json_success($plan);
    }
    
    /**
     * معالجة شراء الاشتراك
     */
    public function handle_subscription_purchase() {
        // التحقق من الأمان
        check_ajax_referer('vt_subscription_purchase', 'nonce');
        
        // التحقق من تسجيل الدخول
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => __('يجب تسجيل الدخول للاشتراك', 'video-translator')));
        }
        
        // التحقق من البيانات المرسلة
        if (!isset($_POST['plan_id'])) {
            wp_send_json_error(array('message' => __('لم يتم تحديد خطة الاشتراك', 'video-translator')));
        }
        
        $plan_id = sanitize_text_field($_POST['plan_id']);
        $plan = $this->get_subscription_plan($plan_id);
        
        if (!$plan) {
            wp_send_json_error(array('message' => __('خطة الاشتراك غير موجودة', 'video-translator')));
        }
        
        // للخطط المجانية، قم بإعداد الاشتراك مباشرة
        if ($plan['price'] == 0) {
            $this->setup_user_subscription(get_current_user_id(), $plan_id);
            
            wp_send_json_success(array(
                'message' => __('تم الاشتراك بنجاح', 'video-translator'),
                'redirect' => isset($_POST['redirect_url']) ? esc_url_raw($_POST['redirect_url']) : '',
            ));
        }
        
        // بالنسبة للخطط المدفوعة، قم بالتوجيه إلى WooCommerce إذا كان نشطاً
        if ($this->is_woocommerce_active() && isset($plan['woo_product_id']) && $plan['woo_product_id'] > 0) {
            $product_id = $plan['woo_product_id'];
            
            // إضافة المنتج إلى السلة
            WC()->cart->empty_cart();
            WC()->cart->add_to_cart($product_id);
            
            // إضافة بيانات الاشتراك كمعلومات إضافية للطلب
            WC()->session->set('vt_subscription_plan_id', $plan_id);
            
            wp_send_json_success(array(
                'redirect' => wc_get_checkout_url(),
            ));
        }
        
        // إذا لم يكن WooCommerce نشطاً، إرجاع خطأ
        wp_send_json_error(array('message' => __('لا يمكن معالجة المدفوعات. يرجى الاتصال بمسؤول الموقع.', 'video-translator')));
    }
    
    /**
     * إعداد اشتراك المستخدم
     *
     * @param int $user_id معرف المستخدم
     * @param string $plan_id معرف خطة الاشتراك
     * @param int $expiry تاريخ انتهاء الصلاحية (اختياري)
     */
    public function setup_user_subscription($user_id, $plan_id, $expiry = null) {
        $plan = $this->get_subscription_plan($plan_id);
        
        if (!$plan) {
            return;
        }
        
        // إعداد تاريخ الانتهاء بناءً على مدة الاشتراك
        if ($expiry === null) {
            if ($plan['duration'] === 'unlimited') {
                $expiry = -1; // غير محدود
            } else {
                $now = time();
                
                switch ($plan['duration']) {
                    case 'day':
                        $expiry = strtotime('+1 day', $now);
                        break;
                    case 'week':
                        $expiry = strtotime('+1 week', $now);
                        break;
                    case 'month':
                        $expiry = strtotime('+1 month', $now);
                        break;
                    case 'year':
                        $expiry = strtotime('+1 year', $now);
                        break;
                    default:
                        $expiry = strtotime('+1 month', $now);
                        break;
                }
            }
        }
        
        // إعداد بيانات الاشتراك
        $subscription_data = array(
            'plan_id' => $plan_id,
            'plan_name' => $plan['name'],
            'start_date' => time(),
            'expiry' => $expiry,
            'max_videos' => $plan['max_videos'],
            'videos_left' => $plan['max_videos'],
            'max_duration' => $plan['max_duration'],
            'features' => $plan['features'],
        );
        
        // حفظ بيانات الاشتراك
        update_user_meta($user_id, 'vt_subscription', $subscription_data);
        
        // تحديث دور المستخدم
        $user = new WP_User($user_id);
        
        // إزالة الأدوار القديمة
        $user->remove_role('vt_subscriber');
        $user->remove_role('vt_premium_subscriber');
        
        // إضافة الدور الجديد بناءً على الميزات المشتراة
        if (in_array('elevenlabs_voices', $plan['features']) || in_array('lip_sync', $plan['features'])) {
            $user->add_role('vt_premium_subscriber');
        } else {
            $user->add_role('vt_subscriber');
        }
        
        // تسجيل حدث الاشتراك
        $this->log_subscription_event($user_id, 'subscribe', $plan_id);
    }
    
    /**
     * معالجة طلب WooCommerce
     *
     * @param int $order_id معرف الطلب
     */
    public function process_woocommerce_order($order_id) {
        $order = wc_get_order($order_id);
        
        // التحقق من وجود بيانات الاشتراك في جلسة المستخدم
        $plan_id = WC()->session->get('vt_subscription_plan_id');
        
        if (!$plan_id) {
            // التحقق من البيانات الوصفية للطلب
            $plan_id = $order->get_meta('vt_subscription_plan_id');
            
            if (!$plan_id) {
                return;
            }
        }
        
        // الحصول على المستخدم من الطلب
        $user_id = $order->get_user_id();
        
        if (!$user_id) {
            return;
        }
        
        // إعداد الاشتراك
        $this->setup_user_subscription($user_id, $plan_id);
        
        // إزالة البيانات من الجلسة
        WC()->session->__unset('vt_subscription_plan_id');
    }
    
    /**
     * معالجة اشتراك WooCommerce
     *
     * @param int $subscription_id معرف الاشتراك
     */
    public function process_woocommerce_subscription($subscription_id) {
        if (!function_exists('wcs_get_subscription')) {
            return;
        }
        
        $subscription = wcs_get_subscription($subscription_id);
        
        if (!$subscription) {
            return;
        }
        
        // الحصول على خطة الاشتراك من البيانات الوصفية
        $plan_id = $subscription->get_meta('vt_subscription_plan_id');
        
        if (!$plan_id) {
            return;
        }
        
        // الحصول على المستخدم من الاشتراك
        $user_id = $subscription->get_user_id();
        
        if (!$user_id) {
            return;
        }
        
        // إعداد تاريخ انتهاء الصلاحية بناءً على تاريخ انتهاء الاشتراك في WooCommerce
        $expiry = $subscription->get_date('end') ? strtotime($subscription->get_date('end')) : -1;
        
        // إعداد الاشتراك
        $this->setup_user_subscription($user_id, $plan_id, $expiry);
    }
    
    /**
     * إلغاء اشتراك WooCommerce
     *
     * @param int $subscription_id معرف الاشتراك
     */
    public function cancel_woocommerce_subscription($subscription_id) {
        if (!function_exists('wcs_get_subscription')) {
            return;
        }
        
        $subscription = wcs_get_subscription($subscription_id);
        
        if (!$subscription) {
            return;
        }
        
        // الحصول على المستخدم من الاشتراك
        $user_id = $subscription->get_user_id();
        
        if (!$user_id) {
            return;
        }
        
        // الحصول على بيانات اشتراك المستخدم
        $user_subscription = get_user_meta($user_id, 'vt_subscription', true);
        
        if (!$user_subscription) {
            return;
        }
        
        // تسجيل إلغاء الاشتراك
        $this->log_subscription_event($user_id, 'cancel', $user_subscription['plan_id']);
        
        // إزالة الاشتراك
        delete_user_meta($user_id, 'vt_subscription');
        
        // إزالة الأدوار المتعلقة بالاشتراك
        $user = new WP_User($user_id);
        $user->remove_role('vt_subscriber');
        $user->remove_role('vt_premium_subscriber');
    }
    
    /**
     * تسجيل حدث اشتراك
     *
     * @param int $user_id معرف المستخدم
     * @param string $event نوع الحدث (subscribe, cancel, expired)
     * @param string $plan_id معرف خطة الاشتراك
     */
    public function log_subscription_event($user_id, $event, $plan_id) {
        $logs = get_option('vt_subscription_logs', array());
        
        $logs[] = array(
            'user_id' => $user_id,
            'event' => $event,
            'plan_id' => $plan_id,
            'timestamp' => time(),
        );
        
        // الاحتفاظ بآخر 1000 سجل فقط
        if (count($logs) > 1000) {
            $logs = array_slice($logs, -1000);
        }
        
        update_option('vt_subscription_logs', $logs);
    }
    
    /**
     * وسم عرض صفحة الدفع
     *
     * @param array $atts سمات الوسم
     * @return string
     */
    public function payment_page_shortcode($atts) {
        $atts = shortcode_atts(array(
            'redirect_url' => '',
            'show_plans' => 'yes',
            'columns' => 3,
            'show_title' => 'yes',
            'title' => __('اختر خطة الاشتراك', 'video-translator'),
            'class' => '',
        ), $atts);
        
        // التحقق من تفعيل نظام الاشتراكات
        $settings = get_option('vt_settings', array());
        $enable_subscription = isset($settings['enable_subscription']) ? $settings['enable_subscription'] : 'yes';
        
        if ($enable_subscription !== 'yes') {
            return '<div class="vt-message vt-info">' . __('نظام الاشتراكات غير مفعل حالياً.', 'video-translator') . '</div>';
        }
        
        // تحقق من تسجيل الدخول
        if (!is_user_logged_in()) {
            $login_url = wp_login_url(get_permalink());
            
            return '<div class="vt-login-required">' .
                   '<p>' . __('يرجى <a href="%s">تسجيل الدخول</a> للاشتراك في خدمة مترجم الفيديو.', 'video-translator') . '</p>' .
                   '</div>';
        }
        
        $output = '<div class="vt-payment-page ' . esc_attr($atts['class']) . '">';
        
        // عرض العنوان
        if ($atts['show_title'] === 'yes') {
            $output .= '<h2 class="vt-payment-title">' . esc_html($atts['title']) . '</h2>';
        }
        
        // عرض الاشتراك الحالي إذا كان موجوداً
        $user_id = get_current_user_id();
        $subscription = get_user_meta($user_id, 'vt_subscription', true);
        
        if (!empty($subscription)) {
            $output .= $this->render_current_subscription($subscription);
        }
        
        // عرض خطط الاشتراك
        if ($atts['show_plans'] === 'yes') {
            $output .= $this->render_subscription_plans($atts['columns'], $atts['redirect_url']);
        }
        
        $output .= '</div>';
        
        // إضافة ملفات CSS
        wp_enqueue_style('vt-subscription-styles', VT_PLUGIN_URL . 'assets/css/subscription-styles.css', array(), VT_PLUGIN_VERSION);
        
        // إضافة JavaScript
        wp_enqueue_script('vt-subscription', VT_PLUGIN_URL . 'assets/js/video-translator.js', array('jquery'), VT_PLUGIN_VERSION, true);
        
        wp_localize_script('vt-subscription', 'vt_subscription', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('vt_subscription_purchase'),
        ));
        
        return $output;
    }
    
    /**
     * عرض الاشتراك الحالي
     *
     * @param array $subscription بيانات الاشتراك
     * @return string
     */
    public function render_current_subscription($subscription) {
        $output = '<div class="vt-current-subscription">';
        $output .= '<h3>' . __('اشتراكك الحالي', 'video-translator') . '</h3>';
        
        $output .= '<div class="vt-subscription-details">';
        $output .= '<p><strong>' . __('الخطة:', 'video-translator') . '</strong> ' . esc_html($subscription['plan_name']) . '</p>';
        
        if ($subscription['expiry'] !== -1) {
            $output .= '<p><strong>' . __('تاريخ الانتهاء:', 'video-translator') . '</strong> ' . date_i18n(get_option('date_format'), $subscription['expiry']) . '</p>';
        } else {
            $output .= '<p><strong>' . __('مدة الاشتراك:', 'video-translator') . '</strong> ' . __('غير محدودة', 'video-translator') . '</p>';
        }
        
        if (isset($subscription['videos_left'])) {
            if ($subscription['videos_left'] !== -1) {
                $output .= '<p><strong>' . __('الفيديوهات المتبقية:', 'video-translator') . '</strong> ' . $subscription['videos_left'] . '</p>';
            } else {
                $output .= '<p><strong>' . __('الفيديوهات المتبقية:', 'video-translator') . '</strong> ' . __('غير محدودة', 'video-translator') . '</p>';
            }
        }
        
        if (isset($subscription['max_duration']) && $subscription['max_duration'] !== -1) {
            $output .= '<p><strong>' . __('الحد الأقصى لمدة الفيديو:', 'video-translator') . '</strong> ' . $subscription['max_duration'] . ' ' . __('دقائق', 'video-translator') . '</p>';
        }
        
        $output .= '<p><strong>' . __('الميزات المتاحة:', 'video-translator') . '</strong></p>';
        $output .= '<ul class="vt-features-list">';
        
        $features_list = array(
            'youtube_support' => __('دعم فيديوهات يوتيوب', 'video-translator'),
            'upload_support' => __('دعم تحميل الفيديوهات', 'video-translator'),
            'elevenlabs_voices' => __('أصوات ElevenLabs المتقدمة', 'video-translator'),
            'lip_sync' => __('مزامنة الشفاه (Lip Sync)', 'video-translator'),
            'download_video' => __('تحميل الفيديو المدبلج', 'video-translator'),
        );
        
        foreach ($subscription['features'] as $feature) {
            if (isset($features_list[$feature])) {
                $output .= '<li>' . esc_html($features_list[$feature]) . '</li>';
            }
        }
        
        $output .= '</ul>';
        $output .= '</div>'; // .vt-subscription-details
        $output .= '</div>'; // .vt-current-subscription
        
        return $output;
    }
    
    /**
     * عرض خطط الاشتراك
     *
     * @param int $columns عدد الأعمدة
     * @param string $redirect_url عنوان إعادة التوجيه
     * @return string
     */
    public function render_subscription_plans($columns, $redirect_url = '') {
        $plans = $this->get_subscription_plans(true);
        
        if (empty($plans)) {
            return '<div class="vt-message vt-info">' . __('لا توجد خطط اشتراك متاحة حالياً.', 'video-translator') . '</div>';
        }
        
        $output = '<div class="vt-subscription-plans">';
        $output .= '<div class="vt-plans-row vt-cols-' . esc_attr($columns) . '">';
        
        $user_id = get_current_user_id();
        $current_subscription = get_user_meta($user_id, 'vt_subscription', true);
        $current_plan_id = !empty($current_subscription) ? $current_subscription['plan_id'] : '';
        
        foreach ($plans as $plan_id => $plan) {
            $output .= '<div class="vt-plan-column">';
            $output .= '<div class="vt-plan-item">';
            
            // رأس الخطة
            $output .= '<div class="vt-plan-header">';
            $output .= '<h3 class="vt-plan-name">' . esc_html($plan['name']) . '</h3>';
            
            // السعر
            $output .= '<div class="vt-plan-price">';
            
            if ($plan['price'] > 0) {
                $output .= '<span class="vt-amount">' . esc_html(number_format($plan['price'], 2)) . '</span>';
                
                // المدة
                if ($plan['duration'] !== 'unlimited') {
                    $duration_text = '';
                    
                    switch ($plan['duration']) {
                        case 'day':
                            $duration_text = __('/ يوم', 'video-translator');
                            break;
                        case 'week':
                            $duration_text = __('/ أسبوع', 'video-translator');
                            break;
                        case 'month':
                            $duration_text = __('/ شهر', 'video-translator');
                            break;
                        case 'year':
                            $duration_text = __('/ سنة', 'video-translator');
                            break;
                    }
                    
                    $output .= '<span class="vt-duration">' . esc_html($duration_text) . '</span>';
                }
            } else {
                $output .= '<span class="vt-amount">' . __('مجاناً', 'video-translator') . '</span>';
            }
            
            $output .= '</div>'; // .vt-plan-price
            $output .= '</div>'; // .vt-plan-header
            
            // ميزات الخطة
            $output .= '<div class="vt-plan-features">';
            $output .= '<ul>';
            
            // حد الفيديوهات
            if ($plan['max_videos'] !== -1) {
                $output .= '<li>' . sprintf(__('حتى %d فيديو', 'video-translator'), $plan['max_videos']) . '</li>';
            } else {
                $output .= '<li>' . __('فيديوهات غير محدودة', 'video-translator') . '</li>';
            }
            
            // حد المدة
            if ($plan['max_duration'] !== -1) {
                $output .= '<li>' . sprintf(__('مدة الفيديو حتى %d دقائق', 'video-translator'), $plan['max_duration']) . '</li>';
            } else {
                $output .= '<li>' . __('مدة فيديو غير محدودة', 'video-translator') . '</li>';
            }
            
            // الميزات الإضافية
            $features_list = array(
                'youtube_support' => __('دعم فيديوهات يوتيوب', 'video-translator'),
                'upload_support' => __('دعم تحميل الفيديوهات', 'video-translator'),
                'elevenlabs_voices' => __('أصوات ElevenLabs المتقدمة', 'video-translator'),
                'lip_sync' => __('مزامنة الشفاه (Lip Sync)', 'video-translator'),
                'download_video' => __('تحميل الفيديو المدبلج', 'video-translator'),
            );
            
            // الحصول على الميزات المدفوعة من الإعدادات
            $settings = get_option('vt_settings', array());
            $premium_features = isset($settings['premium_features']) ? (array) $settings['premium_features'] : array();
            
            foreach ($plan['features'] as $feature) {
                if (isset($features_list[$feature])) {
                    $class = in_array($feature, $premium_features) ? 'vt-premium-feature' : '';
                    $output .= '<li class="' . esc_attr($class) . '">' . esc_html($features_list[$feature]) . '</li>';
                }
            }
            
            $output .= '</ul>';
            $output .= '</div>'; // .vt-plan-features
            
            // زر الشراء
            $output .= '<div class="vt-plan-action">';
            
            if ($current_plan_id === $plan_id) {
                $output .= '<span class="vt-subscribe-status">' . __('أنت مشترك في هذه الخطة', 'video-translator') . '</span>';
            } else {
                $button_class = 'vt-purchase-button';
                $button_text = __('اشترك الآن', 'video-translator');
                
                if ($plan['price'] == 0) {
                    $button_class = 'vt-free-button';
                    $button_text = __('اشترك مجاناً', 'video-translator');
                }
                
                $output .= '<button class="' . esc_attr($button_class) . '" 
                          data-plan-id="' . esc_attr($plan_id) . '" 
                          data-redirect="' . esc_url($redirect_url) . '">' . 
                          esc_html($button_text) . '</button>';
            }
            
            $output .= '</div>'; // .vt-plan-action
            
            $output .= '</div>'; // .vt-plan-item
            $output .= '</div>'; // .vt-plan-column
        }
        
        $output .= '</div>'; // .vt-plans-row
        $output .= '</div>'; // .vt-subscription-plans
        
        return $output;
    }
    
    /**
     * وسم عرض خطط الاشتراك
     *
     * @param array $atts سمات الوسم
     * @return string
     */
    public function plans_shortcode($atts) {
        $atts = shortcode_atts(array(
            'columns' => 3,
            'redirect_url' => '',
        ), $atts);
        
        return $this->render_subscription_plans($atts['columns'], $atts['redirect_url']);
    }
    
    /**
     * عرض صفحة إدارة الاشتراكات في لوحة التحكم
     */
    public function render_admin_page() {
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('إدارة الاشتراكات', 'video-translator'); ?></h1>
            
            <?php
            // إعدادات الاشتراكات
            $settings = get_option('vt_settings', array());
            $enable_subscription = isset($settings['enable_subscription']) ? $settings['enable_subscription'] : 'yes';
            
            if ($enable_subscription !== 'yes') {
                echo '<div class="notice notice-warning"><p>' . esc_html__('نظام الاشتراكات غير مفعل حالياً. يمكنك تفعيله من صفحة الإعدادات.', 'video-translator') . '</p></div>';
            }
            
            // التحقق من الإجراء المطلوب
            $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'list';
            
            switch ($action) {
                case 'add':
                case 'edit':
                    $this->render_plan_form();
                    break;
                
                case 'delete':
                    $this->delete_plan();
                    break;
                
                case 'logs':
                    $this->render_subscription_logs();
                    break;
                
                default:
                    $this->render_plans_list();
                    break;
            }
            ?>
        </div>
        <script>
        jQuery(document).ready(function($) {
            // مراقبة تغيير حقل السعر
            $('#vt-plan-price').on('change', function() {
                var price = parseFloat($(this).val());
                
                // إظهار/إخفاء إعدادات WooCommerce بناءً على السعر
                if (price > 0) {
                    $('.vt-woo-product-field').show();
                } else {
                    $('.vt-woo-product-field').hide();
                }
            }).trigger('change');
            
            // مراقبة تغيير حقل المدة
            $('#vt-plan-duration').on('change', function() {
                var duration = $(this).val();
                
                // إظهار/إخفاء حقل تاريخ الانتهاء بناءً على المدة
                if (duration === 'unlimited') {
                    $('.vt-plan-expiry-field').hide();
                } else {
                    $('.vt-plan-expiry-field').show();
                }
            }).trigger('change');
        });
        </script>
        <?php
    }
    
    /**
     * عرض قائمة خطط الاشتراك
     */
    public function render_plans_list() {
        $plans = get_option('vt_subscription_plans', array());
        ?>
        <div class="tablenav top">
            <div class="alignleft actions">
                <a href="<?php echo esc_url(admin_url('admin.php?page=vt-subscriptions&action=add')); ?>" class="button button-primary"><?php echo esc_html__('إضافة خطة جديدة', 'video-translator'); ?></a>
                <a href="<?php echo esc_url(admin_url('admin.php?page=vt-subscriptions&action=logs')); ?>" class="button"><?php echo esc_html__('عرض سجلات الاشتراكات', 'video-translator'); ?></a>
            </div>
            <br class="clear">
        </div>
        
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php echo esc_html__('الاسم', 'video-translator'); ?></th>
                    <th><?php echo esc_html__('المعرف', 'video-translator'); ?></th>
                    <th><?php echo esc_html__('السعر', 'video-translator'); ?></th>
                    <th><?php echo esc_html__('المدة', 'video-translator'); ?></th>
                    <th><?php echo esc_html__('حد الفيديوهات', 'video-translator'); ?></th>
                    <th><?php echo esc_html__('حد المدة', 'video-translator'); ?></th>
                    <th><?php echo esc_html__('الميزات', 'video-translator'); ?></th>
                    <th><?php echo esc_html__('الحالة', 'video-translator'); ?></th>
                    <th><?php echo esc_html__('الإجراءات', 'video-translator'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($plans)) : ?>
                    <tr>
                        <td colspan="9"><?php echo esc_html__('لا توجد خطط اشتراك.', 'video-translator'); ?></td>
                    </tr>
                <?php else : ?>
                    <?php foreach ($plans as $plan_id => $plan) : ?>
                        <tr>
                            <td><?php echo esc_html($plan['name']); ?></td>
                            <td><?php echo esc_html($plan_id); ?></td>
                            <td>
                                <?php
                                if ($plan['price'] > 0) {
                                    echo esc_html(number_format($plan['price'], 2));
                                } else {
                                    echo esc_html__('مجاناً', 'video-translator');
                                }
                                ?>
                            </td>
                            <td>
                                <?php
                                if ($plan['duration'] === 'unlimited') {
                                    echo esc_html__('غير محدودة', 'video-translator');
                                } else {
                                    $duration_text = '';
                                    
                                    switch ($plan['duration']) {
                                        case 'day':
                                            $duration_text = __('يوم', 'video-translator');
                                            break;
                                        case 'week':
                                            $duration_text = __('أسبوع', 'video-translator');
                                            break;
                                        case 'month':
                                            $duration_text = __('شهر', 'video-translator');
                                            break;
                                        case 'year':
                                            $duration_text = __('سنة', 'video-translator');
                                            break;
                                    }
                                    
                                    echo esc_html($duration_text);
                                }
                                ?>
                            </td>
                            <td>
                                <?php
                                if ($plan['max_videos'] === -1) {
                                    echo esc_html__('غير محدود', 'video-translator');
                                } else {
                                    echo esc_html($plan['max_videos']);
                                }
                                ?>
                            </td>
                            <td>
                                <?php
                                if ($plan['max_duration'] === -1) {
                                    echo esc_html__('غير محدود', 'video-translator');
                                } else {
                                    echo esc_html($plan['max_duration']) . ' ' . esc_html__('دقائق', 'video-translator');
                                }
                                ?>
                            </td>
                            <td>
                                <?php
                                $features_list = array(
                                    'youtube_support' => __('يوتيوب', 'video-translator'),
                                    'upload_support' => __('التحميل', 'video-translator'),
                                    'elevenlabs_voices' => __('ElevenLabs', 'video-translator'),
                                    'lip_sync' => __('مزامنة الشفاه', 'video-translator'),
                                    'download_video' => __('تحميل الفيديو', 'video-translator'),
                                );
                                
                                $feature_names = array();
                                foreach ($plan['features'] as $feature) {
                                    if (isset($features_list[$feature])) {
                                        $feature_names[] = $features_list[$feature];
                                    }
                                }
                                
                                echo esc_html(implode(', ', $feature_names));
                                ?>
                            </td>
                            <td>
                                <?php
                                if (isset($plan['status']) && $plan['status'] === 'active') {
                                    echo '<span class="vt-status-active">' . esc_html__('نشط', 'video-translator') . '</span>';
                                } else {
                                    echo '<span class="vt-status-inactive">' . esc_html__('غير نشط', 'video-translator') . '</span>';
                                }
                                ?>
                            </td>
                            <td>
                                <a href="<?php echo esc_url(admin_url('admin.php?page=vt-subscriptions&action=edit&plan_id=' . $plan_id)); ?>" class="button button-small"><?php echo esc_html__('تعديل', 'video-translator'); ?></a>
                                <a href="<?php echo esc_url(admin_url('admin.php?page=vt-subscriptions&action=delete&plan_id=' . $plan_id . '&_wpnonce=' . wp_create_nonce('vt_delete_plan'))); ?>" class="button button-small" onclick="return confirm('<?php echo esc_js(__('هل أنت متأكد من رغبتك في حذف هذه الخطة؟', 'video-translator')); ?>');"><?php echo esc_html__('حذف', 'video-translator'); ?></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
        
        <div class="vt-default-plans">
            <h3><?php echo esc_html__('استعادة الخطط الافتراضية', 'video-translator'); ?></h3>
            <p><?php echo esc_html__('يمكنك استعادة الخطط الافتراضية في حالة حذف أو تعطيل جميع الخطط.', 'video-translator'); ?></p>
            <form method="post" action="">
                <?php wp_nonce_field('vt_restore_default_plans', 'vt_restore_nonce'); ?>
                <input type="hidden" name="vt_action" value="restore_default_plans">
                <button type="submit" class="button" id="vt-restore-default-plans"><?php echo esc_html__('استعادة الخطط الافتراضية', 'video-translator'); ?></button>
                <span id="vt-default-plans-status"></span>
            </form>
        </div>
        <?php
        
        // معالجة استعادة الخطط الافتراضية
        if (isset($_POST['vt_action']) && $_POST['vt_action'] === 'restore_default_plans' && check_admin_referer('vt_restore_default_plans', 'vt_restore_nonce')) {
            $default_plans = array(
                'free' => array(
                    'name' => __('باقة مجانية', 'video-translator'),
                    'price' => 0,
                    'duration' => 'unlimited',
                    'max_videos' => 3,
                    'max_duration' => 5, // 5 دقائق
                    'features' => array('youtube_support', 'upload_support'),
                    'status' => 'active',
                    'woo_product_id' => 0,
                ),
                'basic' => array(
                    'name' => __('باقة أساسية', 'video-translator'),
                    'price' => 9.99,
                    'duration' => 'month',
                    'max_videos' => 15,
                    'max_duration' => 15, // 15 دقيقة
                    'features' => array('youtube_support', 'upload_support', 'download_video'),
                    'status' => 'active',
                    'woo_product_id' => 0,
                ),
                'premium' => array(
                    'name' => __('باقة متميزة', 'video-translator'),
                    'price' => 19.99,
                    'duration' => 'month',
                    'max_videos' => -1, // غير محدود
                    'max_duration' => 30, // 30 دقيقة
                    'features' => array('youtube_support', 'upload_support', 'elevenlabs_voices', 'download_video'),
                    'status' => 'active',
                    'woo_product_id' => 0,
                ),
                'professional' => array(
                    'name' => __('باقة احترافية', 'video-translator'),
                    'price' => 39.99,
                    'duration' => 'month',
                    'max_videos' => -1, // غير محدود
                    'max_duration' => -1, // غير محدود
                    'features' => array('youtube_support', 'upload_support', 'elevenlabs_voices', 'lip_sync', 'download_video'),
                    'status' => 'active',
                    'woo_product_id' => 0,
                ),
            );
            
            update_option('vt_subscription_plans', $default_plans);
            
            echo '<div class="notice notice-success"><p>' . esc_html__('تمت استعادة الخطط الافتراضية بنجاح.', 'video-translator') . '</p></div>';
            
            // إعادة تحميل الصفحة
            echo '<script>window.location.href = "' . esc_url(admin_url('admin.php?page=vt-subscriptions')) . '";</script>';
        }
    }
    
    /**
     * عرض نموذج إضافة/تعديل خطة
     */
    public function render_plan_form() {
        // التحقق مما إذا كان تعديل أو إضافة
        $editing = isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['plan_id']);
        
        // الحصول على خطة الاشتراك إذا كان تعديل
        $plan = array(
            'name' => '',
            'price' => 0,
            'duration' => 'month',
            'max_videos' => -1,
            'max_duration' => -1,
            'features' => array(),
            'status' => 'active',
            'woo_product_id' => 0,
        );
        
        $plan_id = '';
        
        if ($editing) {
            $plan_id = sanitize_text_field($_GET['plan_id']);
            $plans = get_option('vt_subscription_plans', array());
            
            if (isset($plans[$plan_id])) {
                $plan = wp_parse_args($plans[$plan_id], $plan);
            }
        }
        
        // معالجة النموذج
        if (isset($_POST['vt_save_plan']) && check_admin_referer('vt_save_subscription_plan', 'vt_plan_nonce')) {
            $new_plan_id = sanitize_key($_POST['vt_plan_id']);
            
            // التحقق من أن المعرف غير فارغ وصالح
            if (empty($new_plan_id) || !preg_match('/^[a-z0-9_-]+$/', $new_plan_id)) {
                echo '<div class="notice notice-error"><p>' . esc_html__('يرجى إدخال معرف صالح (حروف صغيرة، أرقام، شرطات).', 'video-translator') . '</p></div>';
            } else {
                $plans = get_option('vt_subscription_plans', array());
                
                // التحقق من أن المعرف غير موجود (في حالة الإضافة)
                if (!$editing && isset($plans[$new_plan_id])) {
                    echo '<div class="notice notice-error"><p>' . esc_html__('معرف الخطة موجود بالفعل. يرجى اختيار معرف آخر.', 'video-translator') . '</p></div>';
                } else {
                    // جمع بيانات الخطة
                    $new_plan = array(
                        'name' => sanitize_text_field($_POST['vt_plan_name']),
                        'price' => floatval($_POST['vt_plan_price']),
                        'duration' => sanitize_text_field($_POST['vt_plan_duration']),
                        'max_videos' => intval($_POST['vt_plan_max_videos']),
                        'max_duration' => intval($_POST['vt_plan_max_duration']),
                        'features' => isset($_POST['vt_plan_features']) ? array_map('sanitize_text_field', $_POST['vt_plan_features']) : array(),
                        'status' => isset($_POST['vt_plan_active']) ? 'active' : 'inactive',
                        'woo_product_id' => intval($_POST['vt_plan_woo_product_id']),
                    );
                    
                    // حفظ الخطة
                    if ($editing && $plan_id !== $new_plan_id) {
                        // إذا تم تغيير المعرف، إزالة الخطة القديمة وإضافة الجديدة
                        unset($plans[$plan_id]);
                    }
                    
                    $plans[$new_plan_id] = $new_plan;
                    update_option('vt_subscription_plans', $plans);
                    
                    echo '<div class="notice notice-success"><p>' . esc_html__('تم حفظ الخطة بنجاح.', 'video-translator') . '</p></div>';
                    
                    // إعادة التوجيه إلى قائمة الخطط
                    echo '<script>window.location.href = "' . esc_url(admin_url('admin.php?page=vt-subscriptions')) . '";</script>';
                }
            }
        }
        
        // قائمة الميزات المتاحة
        $available_features = array(
            'youtube_support' => __('دعم فيديوهات يوتيوب', 'video-translator'),
            'upload_support' => __('دعم تحميل الفيديوهات', 'video-translator'),
            'elevenlabs_voices' => __('أصوات ElevenLabs المتقدمة', 'video-translator'),
            'lip_sync' => __('مزامنة الشفاه (Lip Sync)', 'video-translator'),
            'download_video' => __('تحميل الفيديو المدبلج', 'video-translator'),
        );
        
        // منتجات WooCommerce
        $woo_products = array();
        
        if ($this->is_woocommerce_active()) {
            $args = array(
                'status' => 'publish',
                'limit' => -1,
                'orderby' => 'title',
                'order' => 'ASC',
            );
            
            $products = wc_get_products($args);
            
            foreach ($products as $product) {
                $woo_products[$product->get_id()] = $product->get_name() . ' (' . $product->get_price() . ')';
            }
        }
        ?>
        <h2><?php echo $editing ? esc_html__('تعديل خطة الاشتراك', 'video-translator') : esc_html__('إضافة خطة اشتراك جديدة', 'video-translator'); ?></h2>
        
        <form method="post" action="">
            <?php wp_nonce_field('vt_save_subscription_plan', 'vt_plan_nonce'); ?>
            
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="vt-plan-id"><?php echo esc_html__('معرف الخطة', 'video-translator'); ?></label></th>
                    <td>
                        <input type="text" id="vt-plan-id" name="vt_plan_id" value="<?php echo esc_attr($plan_id); ?>" class="regular-text" <?php echo $editing ? 'readonly' : ''; ?> required>
                        <p class="description"><?php echo esc_html__('معرف فريد للخطة (حروف صغيرة، أرقام، شرطات).', 'video-translator'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="vt-plan-name"><?php echo esc_html__('اسم الخطة', 'video-translator'); ?></label></th>
                    <td>
                        <input type="text" id="vt-plan-name" name="vt_plan_name" value="<?php echo esc_attr($plan['name']); ?>" class="regular-text" required>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="vt-plan-price"><?php echo esc_html__('السعر', 'video-translator'); ?></label></th>
                    <td>
                        <input type="number" id="vt-plan-price" name="vt_plan_price" value="<?php echo esc_attr($plan['price']); ?>" class="regular-text" step="0.01" min="0">
                        <p class="description"><?php echo esc_html__('سعر الخطة. استخدم 0 للخطط المجانية.', 'video-translator'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="vt-plan-duration"><?php echo esc_html__('المدة', 'video-translator'); ?></label></th>
                    <td>
                        <select id="vt-plan-duration" name="vt_plan_duration">
                            <option value="unlimited" <?php selected($plan['duration'], 'unlimited'); ?>><?php echo esc_html__('غير محدودة', 'video-translator'); ?></option>
                            <option value="day" <?php selected($plan['duration'], 'day'); ?>><?php echo esc_html__('يوم', 'video-translator'); ?></option>
                            <option value="week" <?php selected($plan['duration'], 'week'); ?>><?php echo esc_html__('أسبوع', 'video-translator'); ?></option>
                            <option value="month" <?php selected($plan['duration'], 'month'); ?>><?php echo esc_html__('شهر', 'video-translator'); ?></option>
                            <option value="year" <?php selected($plan['duration'], 'year'); ?>><?php echo esc_html__('سنة', 'video-translator'); ?></option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="vt-plan-max-videos"><?php echo esc_html__('حد الفيديوهات', 'video-translator'); ?></label></th>
                    <td>
                        <input type="number" id="vt-plan-max-videos" name="vt_plan_max_videos" value="<?php echo esc_attr($plan['max_videos']); ?>" class="regular-text" min="-1">
                        <p class="description"><?php echo esc_html__('الحد الأقصى لعدد الفيديوهات المسموح بها. استخدم -1 لعدد غير محدود.', 'video-translator'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="vt-plan-max-duration"><?php echo esc_html__('حد المدة (دقائق)', 'video-translator'); ?></label></th>
                    <td>
                        <input type="number" id="vt-plan-max-duration" name="vt_plan_max_duration" value="<?php echo esc_attr($plan['max_duration']); ?>" class="regular-text" min="-1">
                        <p class="description"><?php echo esc_html__('الحد الأقصى لمدة الفيديو بالدقائق. استخدم -1 لمدة غير محدودة.', 'video-translator'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php echo esc_html__('الميزات المتاحة', 'video-translator'); ?></th>
                    <td>
                        <fieldset>
                            <legend class="screen-reader-text"><?php echo esc_html__('الميزات المتاحة', 'video-translator'); ?></legend>
                            
                            <?php foreach ($available_features as $feature_id => $feature_name) : ?>
                                <label>
                                    <input type="checkbox" name="vt_plan_features[]" value="<?php echo esc_attr($feature_id); ?>" <?php checked(in_array($feature_id, $plan['features'])); ?>>
                                    <?php echo esc_html($feature_name); ?>
                                </label><br>
                            <?php endforeach; ?>
                        </fieldset>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php echo esc_html__('حالة الخطة', 'video-translator'); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" name="vt_plan_active" value="1" <?php checked(isset($plan['status']) && $plan['status'] === 'active'); ?>>
                            <?php echo esc_html__('نشط', 'video-translator'); ?>
                        </label>
                        <p class="description"><?php echo esc_html__('تظهر الخطط النشطة فقط للمستخدمين.', 'video-translator'); ?></p>
                    </td>
                </tr>
                
                <?php if ($this->is_woocommerce_active()) : ?>
                    <tr class="vt-woo-product-field" style="<?php echo $plan['price'] > 0 ? '' : 'display: none;'; ?>">
                        <th scope="row"><label for="vt-plan-woo-product-id"><?php echo esc_html__('منتج WooCommerce', 'video-translator'); ?></label></th>
                        <td>
                            <select id="vt-plan-woo-product-id" name="vt_plan_woo_product_id">
                                <option value="0"><?php echo esc_html__('-- اختر منتج --', 'video-translator'); ?></option>
                                <?php foreach ($woo_products as $product_id => $product_name) : ?>
                                    <option value="<?php echo esc_attr($product_id); ?>" <?php selected($plan['woo_product_id'], $product_id); ?>>
                                        <?php echo esc_html($product_name); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description"><?php echo esc_html__('اختر منتج WooCommerce الذي يمثل هذه الخطة.', 'video-translator'); ?></p>
                        </td>
                    </tr>
                <?php endif; ?>
            </table>
            
            <p class="submit">
                <input type="submit" name="vt_save_plan" class="button button-primary" value="<?php echo esc_attr__('حفظ الخطة', 'video-translator'); ?>">
                <a href="<?php echo esc_url(admin_url('admin.php?page=vt-subscriptions')); ?>" class="button"><?php echo esc_html__('إلغاء', 'video-translator'); ?></a>
            </p>
        </form>
        <?php
    }
    
    /**
     * حذف خطة الاشتراك
     */
    public function delete_plan() {
        // التحقق من الأمان
        if (!isset($_GET['plan_id']) || !isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'vt_delete_plan')) {
            wp_die(__('لقد انتهت صلاحية رابط الحذف.', 'video-translator'));
        }
        
        $plan_id = sanitize_text_field($_GET['plan_id']);
        $plans = get_option('vt_subscription_plans', array());
        
        if (isset($plans[$plan_id])) {
            unset($plans[$plan_id]);
            update_option('vt_subscription_plans', $plans);
            
            // إعادة التوجيه مع رسالة نجاح
            wp_redirect(add_query_arg('message', 'deleted', admin_url('admin.php?page=vt-subscriptions')));
            exit;
        }
        
        // إعادة التوجيه مع رسالة خطأ
        wp_redirect(add_query_arg('error', 'not_found', admin_url('admin.php?page=vt-subscriptions')));
        exit;
    }
    
    /**
     * عرض سجلات الاشتراكات
     */
    public function render_subscription_logs() {
        $logs = get_option('vt_subscription_logs', array());
        
        // ترتيب السجلات بحسب الوقت (الأحدث أولاً)
        usort($logs, function($a, $b) {
            return $b['timestamp'] - $a['timestamp'];
        });
        
        // حساب عدد الصفحات
        $items_per_page = 20;
        $total_items = count($logs);
        $total_pages = ceil($total_items / $items_per_page);
        
        // الحصول على رقم الصفحة الحالية
        $page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        
        // الحصول على سجلات الصفحة الحالية
        $logs = array_slice($logs, ($page - 1) * $items_per_page, $items_per_page);
        
        ?>
        <h2><?php echo esc_html__('سجلات الاشتراكات', 'video-translator'); ?></h2>
        
        <div class="tablenav top">
            <div class="alignleft actions">
                <a href="<?php echo esc_url(admin_url('admin.php?page=vt-subscriptions')); ?>" class="button"><?php echo esc_html__('العودة إلى قائمة الخطط', 'video-translator'); ?></a>
            </div>
            
            <?php if ($total_pages > 1) : ?>
                <div class="tablenav-pages">
                    <span class="displaying-num"><?php echo sprintf(_n('%s عنصر', '%s عناصر', $total_items, 'video-translator'), number_format_i18n($total_items)); ?></span>
                    
                    <span class="pagination-links">
                        <?php
                        // روابط التنقل
                        $first_page_url = add_query_arg('paged', 1, admin_url('admin.php?page=vt-subscriptions&action=logs'));
                        $last_page_url = add_query_arg('paged', $total_pages, admin_url('admin.php?page=vt-subscriptions&action=logs'));
                        $prev_page = max(1, $page - 1);
                        $next_page = min($total_pages, $page + 1);
                        $prev_page_url = add_query_arg('paged', $prev_page, admin_url('admin.php?page=vt-subscriptions&action=logs'));
                        $next_page_url = add_query_arg('paged', $next_page, admin_url('admin.php?page=vt-subscriptions&action=logs'));
                        
                        if ($page > 1) {
                            echo '<a class="first-page button" href="' . esc_url($first_page_url) . '"><span aria-hidden="true">&laquo;</span></a>';
                            echo '<a class="prev-page button" href="' . esc_url($prev_page_url) . '"><span aria-hidden="true">&lsaquo;</span></a>';
                        } else {
                            echo '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">&laquo;</span>';
                            echo '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">&lsaquo;</span>';
                        }
                        
                        echo '<span class="paging-input">' . $page . ' ' . __('من', 'video-translator') . ' <span class="total-pages">' . $total_pages . '</span></span>';
                        
                        if ($page < $total_pages) {
                            echo '<a class="next-page button" href="' . esc_url($next_page_url) . '"><span aria-hidden="true">&rsaquo;</span></a>';
                            echo '<a class="last-page button" href="' . esc_url($last_page_url) . '"><span aria-hidden="true">&raquo;</span></a>';
                        } else {
                            echo '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">&rsaquo;</span>';
                            echo '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">&raquo;</span>';
                        }
                        ?>
                    </span>
                </div>
            <?php endif; ?>
            
            <br class="clear">
        </div>
        
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php echo esc_html__('التاريخ', 'video-translator'); ?></th>
                    <th><?php echo esc_html__('المستخدم', 'video-translator'); ?></th>
                    <th><?php echo esc_html__('الحدث', 'video-translator'); ?></th>
                    <th><?php echo esc_html__('خطة الاشتراك', 'video-translator'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($logs)) : ?>
                    <tr>
                        <td colspan="4"><?php echo esc_html__('لا توجد سجلات اشتراكات.', 'video-translator'); ?></td>
                    </tr>
                <?php else : ?>
                    <?php foreach ($logs as $log) : ?>
                        <tr>
                            <td><?php echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $log['timestamp'])); ?></td>
                            <td>
                                <?php
                                $user = get_userdata($log['user_id']);
                                if ($user) {
                                    echo '<a href="' . esc_url(get_edit_user_link($log['user_id'])) . '">' . esc_html($user->display_name) . '</a>';
                                } else {
                                    echo esc_html__('مستخدم غير موجود', 'video-translator');
                                }
                                ?>
                            </td>
                            <td>
                                <?php
                                switch ($log['event']) {
                                    case 'subscribe':
                                        echo esc_html__('اشتراك جديد', 'video-translator');
                                        break;
                                    case 'cancel':
                                        echo esc_html__('إلغاء الاشتراك', 'video-translator');
                                        break;
                                    case 'expired':
                                        echo esc_html__('انتهاء الاشتراك', 'video-translator');
                                        break;
                                    default:
                                        echo esc_html($log['event']);
                                        break;
                                }
                                ?>
                            </td>
                            <td>
                                <?php
                                $plans = get_option('vt_subscription_plans', array());
                                if (isset($plans[$log['plan_id']])) {
                                    echo esc_html($plans[$log['plan_id']]['name']);
                                } else {
                                    echo esc_html($log['plan_id']) . ' (' . esc_html__('غير موجودة حالياً', 'video-translator') . ')';
                                }
                                ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
        <?php
    }
    
    /**
     * تسجيل وحدات Elementor
     */
    public function register_elementor_widgets() {
        // التحقق من تنشيط Elementor
        if (!did_action('elementor/loaded')) {
            return;
        }
        
        // تسجيل وحدة خطط الاشتراك
        if (class_exists('Elementor\Widget_Base')) {
            require_once VT_PLUGIN_DIR . 'includes/elementor/class-video-translator-subscription-plans-widget.php';
            
            $widgets_manager = \Elementor\Plugin::instance()->widgets_manager;
            
            // تسجيل الوحدة
            $widgets_manager->register_widget_type(new Video_Translator_Subscription_Plans_Widget());
        }
    }
}

// تهيئة الفئة
$video_translator_subscriptions = new Video_Translator_Subscriptions();