<?php
/**
 * ودجيت خطط الاشتراك لـ Elementor
 */
class Video_Translator_Subscription_Plans_Widget extends \Elementor\Widget_Base {
    /**
     * الحصول على اسم الودجيت
     * 
     * @return string
     */
    public function get_name() {
        return 'video_translator_subscription_plans';
    }
    
    /**
     * الحصول على عنوان الودجيت
     * 
     * @return string
     */
    public function get_title() {
        return esc_html__('خطط اشتراك مترجم الفيديو', 'video-translator');
    }
    
    /**
     * الحصول على أيقونة الودجيت
     * 
     * @return string
     */
    public function get_icon() {
        return 'eicon-price-table';
    }
    
    /**
     * الحصول على الفئات
     * 
     * @return array
     */
    public function get_categories() {
        return ['general'];
    }
    
    /**
     * تسجيل عناصر تحكم الودجيت
     */
    protected function _register_controls() {
        // قسم الإعدادات العامة
        $this->start_controls_section(
            'section_general',
            [
                'label' => esc_html__('إعدادات عامة', 'video-translator'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'title',
            [
                'label' => esc_html__('العنوان', 'video-translator'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('اختر خطة الاشتراك', 'video-translator'),
            ]
        );
        
        $this->add_control(
            'show_title',
            [
                'label' => esc_html__('إظهار العنوان', 'video-translator'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('نعم', 'video-translator'),
                'label_off' => esc_html__('لا', 'video-translator'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        
        $this->add_control(
            'columns',
            [
                'label' => esc_html__('عدد الأعمدة', 'video-translator'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '3',
                'options' => [
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                ],
            ]
        );
        
        $this->add_control(
            'show_plans',
            [
                'label' => esc_html__('إظهار الخطط', 'video-translator'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('نعم', 'video-translator'),
                'label_off' => esc_html__('لا', 'video-translator'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        
        $this->add_control(
            'redirect_url',
            [
                'label' => esc_html__('رابط إعادة التوجيه بعد الاشتراك', 'video-translator'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => esc_html__('https://example.com', 'video-translator'),
                'show_external' => false,
                'default' => [
                    'url' => '',
                ],
            ]
        );
        
        $this->end_controls_section();
        
        // قسم تنسيق الخطط
        $this->start_controls_section(
            'section_plan_style',
            [
                'label' => esc_html__('تنسيق الخطط', 'video-translator'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'heading_title_style',
            [
                'label' => esc_html__('العنوان', 'video-translator'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .vt-payment-title',
            ]
        );
        
        $this->add_control(
            'title_color',
            [
                'label' => esc_html__('لون العنوان', 'video-translator'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vt-payment-title' => 'color: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_control(
            'heading_plan_style',
            [
                'label' => esc_html__('بطاقة الخطة', 'video-translator'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        
        $this->add_control(
            'plan_background_color',
            [
                'label' => esc_html__('لون خلفية البطاقة', 'video-translator'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vt-plan-item' => 'background-color: {{VALUE}}',
                ],
                'default' => '#ffffff',
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'plan_border',
                'selector' => '{{WRAPPER}} .vt-plan-item',
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'plan_box_shadow',
                'selector' => '{{WRAPPER}} .vt-plan-item',
            ]
        );
        
        $this->add_control(
            'plan_border_radius',
            [
                'label' => esc_html__('دائرية الزوايا', 'video-translator'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .vt-plan-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => 5,
                    'right' => 5,
                    'bottom' => 5,
                    'left' => 5,
                    'unit' => 'px',
                    'isLinked' => true,
                ],
            ]
        );
        
        $this->add_control(
            'plan_padding',
            [
                'label' => esc_html__('الهامش الداخلي', 'video-translator'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .vt-plan-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => 20,
                    'right' => 20,
                    'bottom' => 20,
                    'left' => 20,
                    'unit' => 'px',
                    'isLinked' => true,
                ],
            ]
        );
        
        $this->add_control(
            'heading_plan_header_style',
            [
                'label' => esc_html__('رأس الخطة', 'video-translator'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        
        $this->add_control(
            'plan_header_background_color',
            [
                'label' => esc_html__('لون خلفية الرأس', 'video-translator'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vt-plan-header' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_control(
            'plan_name_color',
            [
                'label' => esc_html__('لون اسم الخطة', 'video-translator'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vt-plan-name' => 'color: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'plan_name_typography',
                'selector' => '{{WRAPPER}} .vt-plan-name',
            ]
        );
        
        $this->add_control(
            'plan_price_color',
            [
                'label' => esc_html__('لون السعر', 'video-translator'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vt-plan-price .vt-amount' => 'color: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'plan_price_typography',
                'selector' => '{{WRAPPER}} .vt-plan-price .vt-amount',
            ]
        );
        
        $this->add_control(
            'heading_plan_features_style',
            [
                'label' => esc_html__('الميزات', 'video-translator'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        
        $this->add_control(
            'features_color',
            [
                'label' => esc_html__('لون النص', 'video-translator'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vt-plan-features ul li' => 'color: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'features_typography',
                'selector' => '{{WRAPPER}} .vt-plan-features ul li',
            ]
        );
        
        $this->add_control(
            'premium_feature_color',
            [
                'label' => esc_html__('لون الميزات المتميزة', 'video-translator'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vt-plan-features ul li.vt-premium-feature' => 'color: {{VALUE}}',
                ],
                'default' => '#e91e63',
            ]
        );
        
        $this->add_control(
            'heading_button_style',
            [
                'label' => esc_html__('زر الاشتراك', 'video-translator'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        
        $this->start_controls_tabs('button_style_tabs');
        
        $this->start_controls_tab(
            'button_normal_tab',
            [
                'label' => esc_html__('العادي', 'video-translator'),
            ]
        );
        
        $this->add_control(
            'button_text_color',
            [
                'label' => esc_html__('لون النص', 'video-translator'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vt-purchase-button, {{WRAPPER}} .vt-free-button' => 'color: {{VALUE}}',
                ],
                'default' => '#ffffff',
            ]
        );
        
        $this->add_control(
            'button_background_color',
            [
                'label' => esc_html__('لون الخلفية', 'video-translator'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vt-purchase-button, {{WRAPPER}} .vt-free-button' => 'background-color: {{VALUE}}',
                ],
                'default' => '#4CAF50',
            ]
        );
        
        $this->end_controls_tab();
        
        $this->start_controls_tab(
            'button_hover_tab',
            [
                'label' => esc_html__('التحويم', 'video-translator'),
            ]
        );
        
        $this->add_control(
            'button_hover_text_color',
            [
                'label' => esc_html__('لون النص', 'video-translator'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vt-purchase-button:hover, {{WRAPPER}} .vt-free-button:hover' => 'color: {{VALUE}}',
                ],
                'default' => '#ffffff',
            ]
        );
        
        $this->add_control(
            'button_hover_background_color',
            [
                'label' => esc_html__('لون الخلفية', 'video-translator'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vt-purchase-button:hover, {{WRAPPER}} .vt-free-button:hover' => 'background-color: {{VALUE}}',
                ],
                'default' => '#388E3C',
            ]
        );
        
        $this->end_controls_tab();
        
        $this->end_controls_tabs();
        
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'selector' => '{{WRAPPER}} .vt-purchase-button, {{WRAPPER}} .vt-free-button',
            ]
        );
        
        $this->add_control(
            'button_padding',
            [
                'label' => esc_html__('الهامش الداخلي', 'video-translator'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .vt-purchase-button, {{WRAPPER}} .vt-free-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => 10,
                    'right' => 20,
                    'bottom' => 10,
                    'left' => 20,
                    'unit' => 'px',
                    'isLinked' => false,
                ],
            ]
        );
        
        $this->add_control(
            'button_border_radius',
            [
                'label' => esc_html__('دائرية الزوايا', 'video-translator'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .vt-purchase-button, {{WRAPPER}} .vt-free-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => 4,
                    'right' => 4,
                    'bottom' => 4,
                    'left' => 4,
                    'unit' => 'px',
                    'isLinked' => true,
                ],
            ]
        );
        
        $this->end_controls_section();
        
        // قسم تنسيق الاشتراك الحالي
        $this->start_controls_section(
            'section_current_subscription_style',
            [
                'label' => esc_html__('تنسيق الاشتراك الحالي', 'video-translator'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'current_subscription_background_color',
            [
                'label' => esc_html__('لون الخلفية', 'video-translator'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vt-current-subscription' => 'background-color: {{VALUE}}',
                ],
                'default' => '#f5f5f5',
            ]
        );
        
        $this->add_control(
            'current_subscription_text_color',
            [
                'label' => esc_html__('لون النص', 'video-translator'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vt-current-subscription' => 'color: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'current_subscription_border',
                'selector' => '{{WRAPPER}} .vt-current-subscription',
            ]
        );
        
        $this->add_control(
            'current_subscription_border_radius',
            [
                'label' => esc_html__('دائرية الزوايا', 'video-translator'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .vt-current-subscription' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => 5,
                    'right' => 5,
                    'bottom' => 5,
                    'left' => 5,
                    'unit' => 'px',
                    'isLinked' => true,
                ],
            ]
        );
        
        $this->add_control(
            'current_subscription_padding',
            [
                'label' => esc_html__('الهامش الداخلي', 'video-translator'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .vt-current-subscription' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => 20,
                    'right' => 20,
                    'bottom' => 20,
                    'left' => 20,
                    'unit' => 'px',
                    'isLinked' => true,
                ],
            ]
        );
        
        $this->add_control(
            'current_subscription_heading_color',
            [
                'label' => esc_html__('لون العنوان', 'video-translator'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .vt-current-subscription h3' => 'color: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'current_subscription_heading_typography',
                'selector' => '{{WRAPPER}} .vt-current-subscription h3',
            ]
        );
        
        $this->end_controls_section();
    }
    
    /**
     * عرض الودجيت
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        
        // استخدام الشورت كود
        $atts = [
            'redirect_url' => !empty($settings['redirect_url']['url']) ? $settings['redirect_url']['url'] : '',
            'show_plans' => $settings['show_plans'],
            'columns' => $settings['columns'],
            'show_title' => $settings['show_title'],
            'title' => $settings['title'],
            'class' => 'elementor-subscription-plans',
        ];
        
        // استدعاء كلاس الاشتراكات
        $subscriptions = new Video_Translator_Subscriptions();
        echo $subscriptions->payment_page_shortcode($atts);
    }
}