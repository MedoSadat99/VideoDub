<?php
/**
 * فئة الشورت كود لعرض نماذج الترجمة في الواجهة الأمامية
 */
class Video_Translator_Shortcodes {
    /**
     * إعدادات الإضافة
     */
    private $settings;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->settings = get_option('vt_settings', array());
        
        // تسجيل الشورت كود لنموذج ترجمة فيديو يوتيوب
        add_shortcode('video_translator_youtube', array($this, 'youtube_form_shortcode'));
        
        // تسجيل الشورت كود لنموذج ترجمة فيديو مرفوع
        add_shortcode('video_translator_upload', array($this, 'upload_form_shortcode'));
        
        // تسجيل الشورت كود للنموذج المدمج (يوتيوب وتحميل)
        add_shortcode('video_translator', array($this, 'combined_form_shortcode'));
        
        // إضافة أحداث AJAX
        add_action('wp_ajax_vt_process_youtube', array($this, 'process_youtube_ajax'));
        add_action('wp_ajax_nopriv_vt_process_youtube', array($this, 'process_youtube_ajax'));
        
        add_action('wp_ajax_vt_process_upload', array($this, 'process_upload_ajax'));
        add_action('wp_ajax_nopriv_vt_process_upload', array($this, 'process_upload_ajax'));
        
        // إضافة الأصول للواجهة الأمامية
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
    }
    
    /**
     * شورت كود نموذج ترجمة فيديو يوتيوب
     */
    public function youtube_form_shortcode($atts) {
        // الإعدادات الافتراضية
        $default_atts = array(
            'default_language' => isset($this->settings['default_language']) ? $this->settings['default_language'] : 'ar',
            'show_title' => 'yes',
            'title' => __('ترجمة ودبلجة فيديو يوتيوب', 'video-translator'),
            'button_text' => __('معالجة الفيديو', 'video-translator'),
            'placeholder' => __('أدخل رابط فيديو يوتيوب...', 'video-translator'),
            'class' => '',
        );
        
        // دمج الإعدادات المخصصة مع الافتراضية
        $atts = shortcode_atts($default_atts, $atts, 'video_translator_youtube');
        
        // التحقق من تفعيل دعم يوتيوب
        $enable_youtube = isset($this->settings['enable_youtube']) ? $this->settings['enable_youtube'] : 'yes';
        
        if ($enable_youtube !== 'yes') {
            return '<div class="vt-error">' . __('دعم يوتيوب غير مفعل في الإعدادات.', 'video-translator') . '</div>';
        }
        
        // الحصول على كائن الفيديو
        $video_translator = new Video_Translator();
        $languages = $video_translator->get_languages();
        
        // بدء مخزن البيانات
        ob_start();
        
        // عرض النموذج
        ?>
        <div class="vt-form-container vt-youtube-form-container <?php echo esc_attr($atts['class']); ?>">
            <?php if ($atts['show_title'] === 'yes') : ?>
                <h3><?php echo esc_html($atts['title']); ?></h3>
            <?php endif; ?>
            
            <div class="vt-form-group">
                <label for="vt-youtube-url-front"><?php echo esc_html__('رابط فيديو يوتيوب:', 'video-translator'); ?></label>
                <input type="text" id="vt-youtube-url-front" class="vt-input" placeholder="<?php echo esc_attr($atts['placeholder']); ?>">
            </div>
            
            <div class="vt-form-group">
                <label for="vt-youtube-language-front"><?php echo esc_html__('اللغة المستهدفة:', 'video-translator'); ?></label>
                <select id="vt-youtube-language-front" class="vt-select">
                    <?php foreach ($languages as $code => $language) : ?>
                        <option value="<?php echo esc_attr($code); ?>" <?php selected($code, $atts['default_language']); ?>>
                            <?php echo esc_html($language['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="vt-form-group">
                <button id="vt-process-youtube-front" class="vt-button"><?php echo esc_html($atts['button_text']); ?></button>
                <span id="vt-youtube-status-front" class="vt-status"></span>
            </div>
            
            <div id="vt-youtube-result-front" class="vt-result" style="display:none;">
                <h4><?php echo esc_html__('الفيديو المدبلج:', 'video-translator'); ?></h4>
                <div class="vt-video-container"></div>
                <p><a href="#" class="vt-button vt-download-link" target="_blank"><?php echo esc_html__('تحميل الفيديو', 'video-translator'); ?></a></p>
            </div>
        </div>
        <?php
        
        // إرجاع البيانات من المخزن
        return ob_get_clean();
    }
    
    /**
     * شورت كود نموذج ترجمة فيديو مرفوع
     */
    public function upload_form_shortcode($atts) {
        // الإعدادات الافتراضية
        $default_atts = array(
            'default_language' => isset($this->settings['default_language']) ? $this->settings['default_language'] : 'ar',
            'show_title' => 'yes',
            'title' => __('ترجمة ودبلجة فيديو مرفوع', 'video-translator'),
            'button_text' => __('معالجة الفيديو', 'video-translator'),
            'upload_text' => __('اختر فيديو', 'video-translator'),
            'class' => '',
        );
        
        // دمج الإعدادات المخصصة مع الافتراضية
        $atts = shortcode_atts($default_atts, $atts, 'video_translator_upload');
        
        // التحقق من تفعيل دعم تحميل الفيديو
        $enable_upload = isset($this->settings['enable_upload']) ? $this->settings['enable_upload'] : 'yes';
        
        if ($enable_upload !== 'yes') {
            return '<div class="vt-error">' . __('دعم تحميل الفيديو غير مفعل في الإعدادات.', 'video-translator') . '</div>';
        }
        
        // الحصول على كائن الفيديو
        $video_translator = new Video_Translator();
        $languages = $video_translator->get_languages();
        
        // بدء مخزن البيانات
        ob_start();
        
        // عرض النموذج
        ?>
        <div class="vt-form-container vt-upload-form-container <?php echo esc_attr($atts['class']); ?>">
            <?php if ($atts['show_title'] === 'yes') : ?>
                <h3><?php echo esc_html($atts['title']); ?></h3>
            <?php endif; ?>
            
            <div class="vt-form-group">
                <label for="vt-upload-video-front"><?php echo esc_html__('اختر ملف فيديو:', 'video-translator'); ?></label>
                <button id="vt-upload-video-front" class="vt-button vt-button-secondary"><?php echo esc_html($atts['upload_text']); ?></button>
                <div id="vt-selected-file-front" class="vt-selected-file"></div>
            </div>
            
            <div class="vt-form-group">
                <label for="vt-upload-language-front"><?php echo esc_html__('اللغة المستهدفة:', 'video-translator'); ?></label>
                <select id="vt-upload-language-front" class="vt-select">
                    <?php foreach ($languages as $code => $language) : ?>
                        <option value="<?php echo esc_attr($code); ?>" <?php selected($code, $atts['default_language']); ?>>
                            <?php echo esc_html($language['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="vt-form-group">
                <button id="vt-process-upload-front" class="vt-button" disabled><?php echo esc_html($atts['button_text']); ?></button>
                <span id="vt-upload-status-front" class="vt-status"></span>
            </div>
            
            <div id="vt-upload-result-front" class="vt-result" style="display:none;">
                <h4><?php echo esc_html__('الفيديو المدبلج:', 'video-translator'); ?></h4>
                <div class="vt-video-container"></div>
                <p><a href="#" class="vt-button vt-download-link" target="_blank"><?php echo esc_html__('تحميل الفيديو', 'video-translator'); ?></a></p>
            </div>
        </div>
        <?php
        
        // إرجاع البيانات من المخزن
        return ob_get_clean();
    }
    
    /**
     * شورت كود النموذج المدمج (يوتيوب وتحميل)
     */
    public function combined_form_shortcode($atts) {
        // الإعدادات الافتراضية
        $default_atts = array(
            'default_language' => isset($this->settings['default_language']) ? $this->settings['default_language'] : 'ar',
            'show_title' => 'yes',
            'title' => __('ترجمة ودبلجة الفيديو', 'video-translator'),
            'button_text' => __('معالجة الفيديو', 'video-translator'),
            'placeholder' => __('أدخل رابط فيديو يوتيوب...', 'video-translator'),
            'upload_text' => __('اختر فيديو', 'video-translator'),
            'youtube_tab' => __('فيديو يوتيوب', 'video-translator'),
            'upload_tab' => __('تحميل فيديو', 'video-translator'),
            'class' => '',
            'subscription_message' => __('يرجى الاشتراك للاستفادة من هذه الميزة.', 'video-translator'),
            'subscription_url' => '',
        );
        
        // دمج الإعدادات المخصصة مع الافتراضية
        $atts = shortcode_atts($default_atts, $atts, 'video_translator');
        
        // التحقق من تفعيل الخيارات
        $enable_youtube = isset($this->settings['enable_youtube']) ? $this->settings['enable_youtube'] : 'yes';
        $enable_upload = isset($this->settings['enable_upload']) ? $this->settings['enable_upload'] : 'yes';
        
        if ($enable_youtube !== 'yes' && $enable_upload !== 'yes') {
            return '<div class="vt-error">' . __('دعم ترجمة الفيديو غير مفعل في الإعدادات.', 'video-translator') . '</div>';
        }
        
        // الحصول على كائن الفيديو
        $video_translator = new Video_Translator();
        $languages = $video_translator->get_languages();
        
        // بدء مخزن البيانات
        ob_start();
        
        // عرض النموذج
        ?>
        <div class="vt-form-container vt-combined-form-container <?php echo esc_attr($atts['class']); ?>">
            <?php if ($atts['show_title'] === 'yes') : ?>
                <h3><?php echo esc_html($atts['title']); ?></h3>
            <?php endif; ?>
            
            <div class="vt-tabs">
                <ul class="vt-tab-nav">
                    <?php if ($enable_youtube === 'yes') : ?>
                        <li class="vt-tab-link active" data-tab="vt-youtube-tab-front"><?php echo esc_html($atts['youtube_tab']); ?></li>
                    <?php endif; ?>
                    
                    <?php if ($enable_upload === 'yes') : ?>
                        <li class="vt-tab-link <?php echo ($enable_youtube !== 'yes') ? 'active' : ''; ?>" data-tab="vt-upload-tab-front"><?php echo esc_html($atts['upload_tab']); ?></li>
                    <?php endif; ?>
                </ul>
                
                <div class="vt-tab-content">
                    <?php if ($enable_youtube === 'yes') : ?>
                        <div id="vt-youtube-tab-front" class="vt-tab-pane active">
                            <div class="vt-form-group">
                                <label for="vt-youtube-url-combined"><?php echo esc_html__('رابط فيديو يوتيوب:', 'video-translator'); ?></label>
                                <input type="text" id="vt-youtube-url-combined" class="vt-input" placeholder="<?php echo esc_attr($atts['placeholder']); ?>">
                            </div>
                            
                            <div class="vt-form-group">
                                <label for="vt-youtube-language-combined"><?php echo esc_html__('اللغة المستهدفة:', 'video-translator'); ?></label>
                                <select id="vt-youtube-language-combined" class="vt-select">
                                    <?php foreach ($languages as $code => $language) : ?>
                                        <option value="<?php echo esc_attr($code); ?>" <?php selected($code, $atts['default_language']); ?>>
                                            <?php echo esc_html($language['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="vt-form-group">
                                <button id="vt-process-youtube-combined" class="vt-button"><?php echo esc_html($atts['button_text']); ?></button>
                                <span id="vt-youtube-status-combined" class="vt-status"></span>
                            </div>
                            
                            <div id="vt-youtube-result-combined" class="vt-result" style="display:none;">
                                <h4><?php echo esc_html__('الفيديو المدبلج:', 'video-translator'); ?></h4>
                                <div class="vt-video-container"></div>
                                <p><a href="#" class="vt-button vt-download-link" target="_blank"><?php echo esc_html__('تحميل الفيديو', 'video-translator'); ?></a></p>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($enable_upload === 'yes') : ?>
                        <div id="vt-upload-tab-front" class="vt-tab-pane <?php echo ($enable_youtube !== 'yes') ? 'active' : ''; ?>">
                            <div class="vt-form-group">
                                <label for="vt-upload-video-combined"><?php echo esc_html__('اختر ملف فيديو:', 'video-translator'); ?></label>
                                <button id="vt-upload-video-combined" class="vt-button vt-button-secondary"><?php echo esc_html($atts['upload_text']); ?></button>
                                <div id="vt-selected-file-combined" class="vt-selected-file"></div>
                            </div>
                            
                            <div class="vt-form-group">
                                <label for="vt-upload-language-combined"><?php echo esc_html__('اللغة المستهدفة:', 'video-translator'); ?></label>
                                <select id="vt-upload-language-combined" class="vt-select">
                                    <?php foreach ($languages as $code => $language) : ?>
                                        <option value="<?php echo esc_attr($code); ?>" <?php selected($code, $atts['default_language']); ?>>
                                            <?php echo esc_html($language['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="vt-form-group">
                                <button id="vt-process-upload-combined" class="vt-button" disabled><?php echo esc_html($atts['button_text']); ?></button>
                                <span id="vt-upload-status-combined" class="vt-status"></span>
                            </div>
                            
                            <div id="vt-upload-result-combined" class="vt-result" style="display:none;">
                                <h4><?php echo esc_html__('الفيديو المدبلج:', 'video-translator'); ?></h4>
                                <div class="vt-video-container"></div>
                                <p><a href="#" class="vt-button vt-download-link" target="_blank"><?php echo esc_html__('تحميل الفيديو', 'video-translator'); ?></a></p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
        
        // إرجاع البيانات من المخزن
        return ob_get_clean();
    }
    
    /**
     * إضافة ملفات JavaScript و CSS للواجهة الأمامية
     */
    public function enqueue_frontend_assets() {
        wp_enqueue_style(
            'vt-frontend-style',
            VT_PLUGIN_URL . 'assets/css/video-translator.css',
            array(),
            VT_PLUGIN_VERSION
        );
        
        // إضافة CSS الاشتراكات إذا كان نظام الاشتراكات مفعل
        $settings = get_option('vt_settings', array());
        $enable_subscription = isset($settings['enable_subscription']) ? $settings['enable_subscription'] : 'yes';
        
        if ($enable_subscription === 'yes') {
            wp_enqueue_style(
                'vt-subscription-style',
                VT_PLUGIN_URL . 'assets/css/subscription-styles.css',
                array(),
                VT_PLUGIN_VERSION
            );
        }
        
        wp_enqueue_script(
            'vt-frontend',
            VT_PLUGIN_URL . 'assets/js/video-translator.js',
            array('jquery', 'media-upload'),
            VT_PLUGIN_VERSION,
            true
        );
        
        wp_localize_script('vt-frontend', 'vt_frontend', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('vt_process_nonce'),
            'subscription_enabled' => $enable_subscription,
            'premium_features' => isset($settings['premium_features']) ? (array) $settings['premium_features'] : array(),
            'is_user_logged_in' => is_user_logged_in(),
            'messages' => array(
                'error' => __('حدث خطأ. يرجى المحاولة مرة أخرى.', 'video-translator'),
                'processing' => __('جاري المعالجة...', 'video-translator'),
                'completed' => __('تمت المعالجة بنجاح!', 'video-translator'),
                'download' => __('تحميل الفيديو', 'video-translator'),
                'select_file' => __('اختر ملف فيديو', 'video-translator'),
                'file_selected' => __('تم اختيار الملف:', 'video-translator'),
                'invalid_url' => __('يرجى إدخال رابط يوتيوب صالح', 'video-translator'),
                'select_language' => __('يرجى اختيار لغة', 'video-translator'),
                'no_file' => __('يرجى اختيار ملف فيديو', 'video-translator'),
                'subscription_required' => __('يرجى الاشتراك للاستفادة من هذه الميزة.', 'video-translator'),
                'login_required' => __('يرجى تسجيل الدخول أولاً.', 'video-translator'),
            ),
        ));
    }
    
    /**
     * معالجة طلب ترجمة فيديو يوتيوب
     */
    public function process_youtube_ajax() {
        // التحقق من الأمان
        check_ajax_referer('vt_process_nonce', 'nonce');
        
        // الحصول على البيانات
        $youtube_url = isset($_POST['youtube_url']) ? sanitize_text_field($_POST['youtube_url']) : '';
        $language = isset($_POST['language']) ? sanitize_text_field($_POST['language']) : '';
        
        if (empty($youtube_url) || empty($language)) {
            wp_send_json_error(array('message' => __('بيانات غير كافية', 'video-translator')));
        }
        
        // التحقق من صلاحية الوصول للميزة
        if (!$this->can_use_feature('youtube_support')) {
            wp_send_json_error(array(
                'message' => __('ليس لديك صلاحية استخدام هذه الميزة. يرجى الاشتراك.', 'video-translator'),
                'code' => 'subscription_required'
            ));
        }
        
        // تجهيز طلب المعالجة
        // هنا يمكن وضع الكود الفعلي لمعالجة الفيديو من يوتيوب
        
        // إرجاع النتيجة (مثال)
        wp_send_json_success(array(
            'message' => __('تمت معالجة فيديو اليوتيوب بنجاح', 'video-translator'),
            'video_url' => admin_url('admin-ajax.php?action=vt_get_video&file=processed_youtube_video.mp4'),
            'download_url' => admin_url('admin-ajax.php?action=vt_download_video&file=processed_youtube_video.mp4'),
        ));
    }
    
    /**
     * معالجة طلب ترجمة فيديو مرفوع
     */
    public function process_upload_ajax() {
        // التحقق من الأمان
        check_ajax_referer('vt_process_nonce', 'nonce');
        
        // الحصول على البيانات
        $attachment_id = isset($_POST['attachment_id']) ? intval($_POST['attachment_id']) : 0;
        $language = isset($_POST['language']) ? sanitize_text_field($_POST['language']) : '';
        
        if (empty($attachment_id) || empty($language)) {
            wp_send_json_error(array('message' => __('بيانات غير كافية', 'video-translator')));
        }
        
        // التحقق من صلاحية الوصول للميزة
        if (!$this->can_use_feature('upload_support')) {
            wp_send_json_error(array(
                'message' => __('ليس لديك صلاحية استخدام هذه الميزة. يرجى الاشتراك.', 'video-translator'),
                'code' => 'subscription_required'
            ));
        }
        
        // تجهيز طلب المعالجة
        // هنا يمكن وضع الكود الفعلي لمعالجة الفيديو المرفوع
        
        // إرجاع النتيجة (مثال)
        wp_send_json_success(array(
            'message' => __('تمت معالجة الفيديو المرفوع بنجاح', 'video-translator'),
            'video_url' => admin_url('admin-ajax.php?action=vt_get_video&file=processed_upload_video.mp4'),
            'download_url' => admin_url('admin-ajax.php?action=vt_download_video&file=processed_upload_video.mp4'),
        ));
    }
    
    /**
     * التحقق من صلاحية استخدام ميزة معينة
     *
     * @param string $feature اسم الميزة
     * @return bool
     */
    private function can_use_feature($feature) {
        // التحقق من تفعيل نظام الاشتراكات
        $settings = get_option('vt_settings', array());
        $enable_subscription = isset($settings['enable_subscription']) ? $settings['enable_subscription'] : 'yes';
        
        if ($enable_subscription !== 'yes') {
            return true; // نظام الاشتراكات غير مفعل، السماح بالوصول للجميع
        }
        
        // إذا كان المستخدم مديراً، السماح بالوصول دائماً
        if (current_user_can('administrator') || current_user_can('vt_manage_subscriptions')) {
            return true;
        }
        
        // الحصول على الميزات المدفوعة
        $premium_features = isset($settings['premium_features']) ? (array) $settings['premium_features'] : array();
        
        // إذا لم تكن الميزة مدفوعة، السماح بالوصول
        if (!in_array($feature, $premium_features)) {
            return true;
        }
        
        // التحقق من وجود filter للتحقق من الاشتراك
        $can_use = apply_filters('vt_can_use_feature', false, $feature);
        
        return $can_use;
    }
}