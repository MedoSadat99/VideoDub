<?php
/**
 * فئة إدارة ملف المستخدم واشتراكاته
 */
class Video_Translator_User_Profile {
    /**
     * Constructor
     */
    public function __construct() {
        // إضافة حقول إضافية في ملف المستخدم
        add_action('show_user_profile', array($this, 'add_subscription_fields'));
        add_action('edit_user_profile', array($this, 'add_subscription_fields'));
        
        // حفظ البيانات المدخلة في ملف المستخدم
        add_action('personal_options_update', array($this, 'save_subscription_fields'));
        add_action('edit_user_profile_update', array($this, 'save_subscription_fields'));
        
        // إضافة أعمدة في صفحة إدارة المستخدمين
        add_filter('manage_users_columns', array($this, 'add_subscription_column'));
        add_filter('manage_users_custom_column', array($this, 'show_subscription_data'), 10, 3);
        
        // إضافة تصفية في صفحة إدارة المستخدمين
        add_action('restrict_manage_users', array($this, 'add_subscription_filter'));
        add_filter('pre_get_users', array($this, 'filter_users_by_subscription'));
    }
    
    /**
     * إضافة حقول الاشتراك في صفحة ملف المستخدم
     */
    public function add_subscription_fields($user) {
        // التحقق من الصلاحيات
        if (!current_user_can('edit_user', $user->ID) && !current_user_can('vt_manage_subscriptions')) {
            return;
        }
        
        // الحصول على بيانات الاشتراك
        $subscription = get_user_meta($user->ID, 'vt_subscription', true);
        
        // الحصول على خطط الاشتراك المتاحة
        $subscription_plans = get_option('vt_subscription_plans', array());
        
        ?>
        <h3><?php _e('اشتراك مترجم الفيديو', 'video-translator'); ?></h3>
        
        <table class="form-table">
            <tr>
                <th><label for="vt_has_subscription"><?php _e('يملك اشتراك', 'video-translator'); ?></label></th>
                <td>
                    <input type="checkbox" name="vt_has_subscription" id="vt_has_subscription" <?php checked(!empty($subscription)); ?> />
                    <span class="description"><?php _e('هل المستخدم يملك اشتراك نشط؟', 'video-translator'); ?></span>
                </td>
            </tr>
            
            <tr class="vt-subscription-fields" style="<?php echo empty($subscription) ? 'display:none;' : ''; ?>">
                <th><label for="vt_subscription_plan"><?php _e('خطة الاشتراك', 'video-translator'); ?></label></th>
                <td>
                    <select name="vt_subscription_plan" id="vt_subscription_plan">
                        <option value=""><?php _e('-- اختر خطة --', 'video-translator'); ?></option>
                        <?php
                        foreach ($subscription_plans as $plan_id => $plan) {
                            echo '<option value="' . esc_attr($plan_id) . '" ' . selected(isset($subscription['plan_id']) && $subscription['plan_id'] === $plan_id, true, false) . '>' . esc_html($plan['name']) . '</option>';
                        }
                        ?>
                    </select>
                </td>
            </tr>
            
            <tr class="vt-subscription-fields" style="<?php echo empty($subscription) ? 'display:none;' : ''; ?>">
                <th><label for="vt_subscription_expiry"><?php _e('تاريخ انتهاء الاشتراك', 'video-translator'); ?></label></th>
                <td>
                    <input type="text" name="vt_subscription_expiry" id="vt_subscription_expiry" class="regular-text" value="<?php echo !empty($subscription['expiry']) && $subscription['expiry'] !== -1 ? date('Y-m-d', $subscription['expiry']) : ''; ?>" placeholder="YYYY-MM-DD" />
                    <p class="description"><?php _e('اترك الحقل فارغاً لاشتراك غير محدود المدة', 'video-translator'); ?></p>
                </td>
            </tr>
            
            <tr class="vt-subscription-fields" style="<?php echo empty($subscription) ? 'display:none;' : ''; ?>">
                <th><label for="vt_subscription_videos_left"><?php _e('الفيديوهات المتبقية', 'video-translator'); ?></label></th>
                <td>
                    <input type="number" name="vt_subscription_videos_left" id="vt_subscription_videos_left" class="regular-text" value="<?php echo isset($subscription['videos_left']) ? esc_attr($subscription['videos_left']) : ''; ?>" min="-1" />
                    <p class="description"><?php _e('استخدم -1 لعدد غير محدود من الفيديوهات', 'video-translator'); ?></p>
                </td>
            </tr>
            
            <tr class="vt-subscription-fields" style="<?php echo empty($subscription) ? 'display:none;' : ''; ?>">
                <th><label for="vt_subscription_max_duration"><?php _e('الحد الأقصى لمدة الفيديو (دقائق)', 'video-translator'); ?></label></th>
                <td>
                    <input type="number" name="vt_subscription_max_duration" id="vt_subscription_max_duration" class="regular-text" value="<?php echo isset($subscription['max_duration']) ? esc_attr($subscription['max_duration']) : ''; ?>" min="-1" />
                    <p class="description"><?php _e('استخدم -1 لمدة غير محدودة', 'video-translator'); ?></p>
                </td>
            </tr>
            
            <tr class="vt-subscription-fields" style="<?php echo empty($subscription) ? 'display:none;' : ''; ?>">
                <th><label><?php _e('الميزات المتاحة', 'video-translator'); ?></label></th>
                <td>
                    <fieldset>
                        <legend class="screen-reader-text"><?php _e('الميزات المتاحة', 'video-translator'); ?></legend>
                        
                        <label>
                            <input type="checkbox" name="vt_subscription_features[]" value="youtube_support" <?php echo !empty($subscription['features']) && in_array('youtube_support', $subscription['features']) ? 'checked' : ''; ?> />
                            <?php _e('دعم فيديوهات يوتيوب', 'video-translator'); ?>
                        </label><br>
                        
                        <label>
                            <input type="checkbox" name="vt_subscription_features[]" value="upload_support" <?php echo !empty($subscription['features']) && in_array('upload_support', $subscription['features']) ? 'checked' : ''; ?> />
                            <?php _e('دعم تحميل الفيديوهات', 'video-translator'); ?>
                        </label><br>
                        
                        <label>
                            <input type="checkbox" name="vt_subscription_features[]" value="elevenlabs_voices" <?php echo !empty($subscription['features']) && in_array('elevenlabs_voices', $subscription['features']) ? 'checked' : ''; ?> />
                            <?php _e('دعم أصوات ElevenLabs المتقدمة', 'video-translator'); ?>
                        </label><br>
                        
                        <label>
                            <input type="checkbox" name="vt_subscription_features[]" value="lip_sync" <?php echo !empty($subscription['features']) && in_array('lip_sync', $subscription['features']) ? 'checked' : ''; ?> />
                            <?php _e('مزامنة الشفاه (Lip Sync)', 'video-translator'); ?>
                        </label><br>
                        
                        <label>
                            <input type="checkbox" name="vt_subscription_features[]" value="download_video" <?php echo !empty($subscription['features']) && in_array('download_video', $subscription['features']) ? 'checked' : ''; ?> />
                            <?php _e('تحميل الفيديو المدبلج', 'video-translator'); ?>
                        </label>
                    </fieldset>
                </td>
            </tr>
        </table>
        
        <script>
        jQuery(document).ready(function($) {
            // إظهار/إخفاء حقول الاشتراك
            $('#vt_has_subscription').on('change', function() {
                if ($(this).is(':checked')) {
                    $('.vt-subscription-fields').show();
                } else {
                    $('.vt-subscription-fields').hide();
                }
            });
            
            // تحديث الحقول عند تغيير الخطة
            $('#vt_subscription_plan').on('change', function() {
                var planId = $(this).val();
                
                if (planId) {
                    // الحصول على بيانات الخطة عبر Ajax
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'vt_get_subscription_plan',
                            plan_id: planId,
                            nonce: '<?php echo wp_create_nonce('vt_get_subscription_plan'); ?>'
                        },
                        success: function(response) {
                            if (response.success) {
                                var plan = response.data;
                                
                                // تحديث حقول الاشتراك
                                $('#vt_subscription_videos_left').val(plan.max_videos);
                                $('#vt_subscription_max_duration').val(plan.max_duration);
                                
                                // تحديث تاريخ الانتهاء
                                if (plan.duration === 'unlimited') {
                                    $('#vt_subscription_expiry').val('');
                                } else {
                                    var now = new Date();
                                    var expiry = new Date();
                                    
                                    switch (plan.duration) {
                                        case 'day':
                                            expiry.setDate(now.getDate() + 1);
                                            break;
                                        case 'week':
                                            expiry.setDate(now.getDate() + 7);
                                            break;
                                        case 'month':
                                            expiry.setMonth(now.getMonth() + 1);
                                            break;
                                        case 'year':
                                            expiry.setFullYear(now.getFullYear() + 1);
                                            break;
                                    }
                                    
                                    var yyyy = expiry.getFullYear();
                                    var mm = String(expiry.getMonth() + 1).padStart(2, '0');
                                    var dd = String(expiry.getDate()).padStart(2, '0');
                                    
                                    $('#vt_subscription_expiry').val(yyyy + '-' + mm + '-' + dd);
                                }
                                
                                // تحديد الميزات
                                $('input[name="vt_subscription_features[]"]').prop('checked', false);
                                $.each(plan.features, function(index, feature) {
                                    $('input[name="vt_subscription_features[]"][value="' + feature + '"]').prop('checked', true);
                                });
                            }
                        }
                    });
                }
            });
        });
        </script>
        <?php
    }
    
    /**
     * حفظ حقول الاشتراك
     */
    public function save_subscription_fields($user_id) {
        // التحقق من الصلاحيات
        if (!current_user_can('edit_user', $user_id) && !current_user_can('vt_manage_subscriptions')) {
            return;
        }
        
        // التحقق مما إذا كان المستخدم يملك اشتراك
        $has_subscription = isset($_POST['vt_has_subscription']);
        
        if ($has_subscription) {
            // الحصول على معرّف الخطة
            $plan_id = sanitize_text_field($_POST['vt_subscription_plan']);
            
            // إذا لم يتم تحديد خطة، لا تفعل شيئاً
            if (empty($plan_id)) {
                return;
            }
            
            // الحصول على خطط الاشتراك
            $subscription_plans = get_option('vt_subscription_plans', array());
            
            // التحقق من وجود الخطة
            if (!isset($subscription_plans[$plan_id])) {
                return;
            }
            
            $plan = $subscription_plans[$plan_id];
            
            // إعداد تاريخ انتهاء الصلاحية
            $expiry = -1; // غير محدود افتراضياً
            
            if (!empty($_POST['vt_subscription_expiry'])) {
                $expiry_date = sanitize_text_field($_POST['vt_subscription_expiry']);
                $expiry = strtotime($expiry_date);
            }
            
            // إعداد بيانات الاشتراك
            $subscription_data = array(
                'plan_id' => $plan_id,
                'plan_name' => $plan['name'],
                'start_date' => time(),
                'expiry' => $expiry,
                'max_videos' => isset($_POST['vt_subscription_videos_left']) ? intval($_POST['vt_subscription_videos_left']) : $plan['max_videos'],
                'videos_left' => isset($_POST['vt_subscription_videos_left']) ? intval($_POST['vt_subscription_videos_left']) : $plan['max_videos'],
                'max_duration' => isset($_POST['vt_subscription_max_duration']) ? intval($_POST['vt_subscription_max_duration']) : $plan['max_duration'],
            );
            
            // إعداد الميزات
            $features = isset($_POST['vt_subscription_features']) ? (array) $_POST['vt_subscription_features'] : array();
            $subscription_data['features'] = array_map('sanitize_text_field', $features);
            
            // حفظ بيانات الاشتراك
            update_user_meta($user_id, 'vt_subscription', $subscription_data);
            
            // تحديث دور المستخدم
            $user = new WP_User($user_id);
            
            // إزالة الأدوار القديمة
            $user->remove_role('vt_subscriber');
            $user->remove_role('vt_premium_subscriber');
            
            // إضافة الدور الجديد بناءً على الميزات المشتراة
            if (in_array('elevenlabs_voices', $features) || in_array('lip_sync', $features)) {
                $user->add_role('vt_premium_subscriber');
            } else {
                $user->add_role('vt_subscriber');
            }
        } else {
            // إزالة الاشتراك
            delete_user_meta($user_id, 'vt_subscription');
            
            // إزالة الأدوار المتعلقة بالاشتراك
            $user = new WP_User($user_id);
            $user->remove_role('vt_subscriber');
            $user->remove_role('vt_premium_subscriber');
        }
    }
    
    /**
     * إضافة عمود الاشتراك في صفحة إدارة المستخدمين
     */
    public function add_subscription_column($columns) {
        $columns['vt_subscription'] = __('اشتراك مترجم الفيديو', 'video-translator');
        return $columns;
    }
    
    /**
     * عرض بيانات الاشتراك في صفحة إدارة المستخدمين
     */
    public function show_subscription_data($value, $column_name, $user_id) {
        if ($column_name !== 'vt_subscription') {
            return $value;
        }
        
        $subscription = get_user_meta($user_id, 'vt_subscription', true);
        
        if (empty($subscription)) {
            return __('لا يوجد اشتراك', 'video-translator');
        }
        
        $output = '<strong>' . esc_html($subscription['plan_name']) . '</strong><br>';
        
        // إضافة تاريخ الانتهاء
        if ($subscription['expiry'] !== -1) {
            $output .= __('ينتهي في:', 'video-translator') . ' ' . date_i18n(get_option('date_format'), $subscription['expiry']) . '<br>';
        } else {
            $output .= __('اشتراك غير محدود المدة', 'video-translator') . '<br>';
        }
        
        // إضافة عدد الفيديوهات المتبقية
        if (isset($subscription['videos_left'])) {
            if ($subscription['videos_left'] !== -1) {
                $output .= __('الفيديوهات المتبقية:', 'video-translator') . ' ' . $subscription['videos_left'];
            } else {
                $output .= __('فيديوهات غير محدودة', 'video-translator');
            }
        }
        
        return $output;
    }
    
    /**
     * إضافة تصفية الاشتراك في صفحة إدارة المستخدمين
     */
    public function add_subscription_filter() {
        // الحصول على القيمة الحالية للتصفية
        $selected = isset($_GET['vt_subscription_filter']) ? $_GET['vt_subscription_filter'] : '';
        
        // الحصول على خطط الاشتراك
        $subscription_plans = get_option('vt_subscription_plans', array());
        
        // عرض قائمة التصفية
        ?>
        <label for="vt-subscription-filter" class="screen-reader-text"><?php _e('تصفية حسب الاشتراك', 'video-translator'); ?></label>
        <select name="vt_subscription_filter" id="vt-subscription-filter">
            <option value=""><?php _e('كل الاشتراكات', 'video-translator'); ?></option>
            <option value="none" <?php selected($selected, 'none'); ?>><?php _e('بدون اشتراك', 'video-translator'); ?></option>
            <option value="any" <?php selected($selected, 'any'); ?>><?php _e('أي اشتراك', 'video-translator'); ?></option>
            <option value="active" <?php selected($selected, 'active'); ?>><?php _e('اشتراكات نشطة', 'video-translator'); ?></option>
            <option value="expired" <?php selected($selected, 'expired'); ?>><?php _e('اشتراكات منتهية', 'video-translator'); ?></option>
            
            <?php if (!empty($subscription_plans)) : ?>
                <optgroup label="<?php _e('تصفية حسب الخطة', 'video-translator'); ?>">
                    <?php foreach ($subscription_plans as $plan_id => $plan) : ?>
                        <option value="<?php echo esc_attr($plan_id); ?>" <?php selected($selected, $plan_id); ?>><?php echo esc_html($plan['name']); ?></option>
                    <?php endforeach; ?>
                </optgroup>
            <?php endif; ?>
        </select>
        <?php
    }
    
    /**
     * تصفية المستخدمين حسب الاشتراك
     */
    public function filter_users_by_subscription($query) {
        global $pagenow;
        
        if ($pagenow !== 'users.php') {
            return;
        }
        
        if (!isset($_GET['vt_subscription_filter']) || empty($_GET['vt_subscription_filter'])) {
            return;
        }
        
        $meta_query = array();
        
        $filter_value = sanitize_text_field($_GET['vt_subscription_filter']);
        
        switch ($filter_value) {
            case 'none':
                // المستخدمون بدون اشتراك
                $meta_query[] = array(
                    'relation' => 'OR',
                    array(
                        'key' => 'vt_subscription',
                        'compare' => 'NOT EXISTS',
                    ),
                    array(
                        'key' => 'vt_subscription',
                        'value' => '',
                        'compare' => '=',
                    ),
                );
                break;
                
            case 'any':
                // المستخدمون الذين لديهم أي اشتراك
                $meta_query[] = array(
                    'key' => 'vt_subscription',
                    'compare' => 'EXISTS',
                );
                break;
                
            case 'active':
                // المستخدمون ذوي الاشتراكات النشطة
                $now = time();
                
                $meta_query['relation'] = 'AND';
                
                $meta_query[] = array(
                    'key' => 'vt_subscription',
                    'compare' => 'EXISTS',
                );
                
                $meta_query[] = array(
                    'relation' => 'OR',
                    array(
                        'key' => 'vt_subscription',
                        'value' => '"expiry";i:-1',
                        'compare' => 'LIKE',
                    ),
                    array(
                        'key' => 'vt_subscription',
                        'value' => '"expiry";i:' . $now,
                        'compare' => 'LIKE',
                        'type' => 'NUMERIC',
                    ),
                );
                break;
                
            case 'expired':
                // المستخدمون ذوي الاشتراكات المنتهية
                $now = time();
                
                $meta_query['relation'] = 'AND';
                
                $meta_query[] = array(
                    'key' => 'vt_subscription',
                    'compare' => 'EXISTS',
                );
                
                $meta_query[] = array(
                    'key' => 'vt_subscription',
                    'value' => '"expiry";i:' . $now,
                    'compare' => '<',
                    'type' => 'NUMERIC',
                );
                break;
                
            default:
                // تصفية حسب الخطة
                $meta_query[] = array(
                    'key' => 'vt_subscription',
                    'value' => '"plan_id";s:' . strlen($filter_value) . ':"' . $filter_value . '"',
                    'compare' => 'LIKE',
                );
                break;
        }
        
        // إضافة استعلام meta للاستعلام الرئيسي
        $query->set('meta_query', $meta_query);
    }
}

// تهيئة الفئة
new Video_Translator_User_Profile();