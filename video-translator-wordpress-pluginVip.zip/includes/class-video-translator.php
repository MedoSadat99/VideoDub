<?php
/**
 * الكلاس الرئيسي للتعامل مع ترجمة الفيديو
 */
class Video_Translator {
    /**
     * إعدادات الإضافة
     */
    private $settings;
    
    /**
     * اللغات المدعومة
     */
    private $languages;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->settings = get_option('vt_settings', array());
        
        // تهيئة اللغات المدعومة
        $this->languages = array(
            'ar' => array('name' => 'العربية', 'code' => 'ar', 'deepl_code' => 'AR'),
            'en' => array('name' => 'الإنجليزية', 'code' => 'en', 'deepl_code' => 'EN-US'),
            'es' => array('name' => 'الإسبانية', 'code' => 'es', 'deepl_code' => 'ES'),
            'fr' => array('name' => 'الفرنسية', 'code' => 'fr', 'deepl_code' => 'FR'),
            'de' => array('name' => 'الألمانية', 'code' => 'de', 'deepl_code' => 'DE'),
            'it' => array('name' => 'الإيطالية', 'code' => 'it', 'deepl_code' => 'IT'),
            'ja' => array('name' => 'اليابانية', 'code' => 'ja', 'deepl_code' => 'JA'),
            'pt' => array('name' => 'البرتغالية', 'code' => 'pt', 'deepl_code' => 'PT-BR'),
            'ru' => array('name' => 'الروسية', 'code' => 'ru', 'deepl_code' => 'RU'),
            'zh' => array('name' => 'الصينية', 'code' => 'zh-CN', 'deepl_code' => 'ZH'),
        );
        
        // تسجيل أحداث AJAX
        add_action('wp_ajax_vt_process_youtube', array($this, 'ajax_process_youtube'));
        add_action('wp_ajax_nopriv_vt_process_youtube', array($this, 'ajax_process_youtube'));
        
        add_action('wp_ajax_vt_process_uploaded_video', array($this, 'ajax_process_uploaded_video'));
        add_action('wp_ajax_nopriv_vt_process_uploaded_video', array($this, 'ajax_process_uploaded_video'));
        
        // تسجيل أحداث لتنظيف الملفات المؤقتة
        add_action('wp_ajax_vt_cleanup_temp_files', array($this, 'ajax_cleanup_temp_files'));
        
        // إضافة الأصول (CSS و JS)
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
    }
    
    /**
     * تضمين ملفات JS و CSS
     */
    public function enqueue_scripts() {
        wp_enqueue_style(
            'vt-styles', 
            VT_PLUGIN_URL . 'assets/css/video-translator.css',
            array(),
            VT_PLUGIN_VERSION
        );
        
        wp_enqueue_script(
            'vt-scripts',
            VT_PLUGIN_URL . 'assets/js/video-translator.js',
            array('jquery'),
            VT_PLUGIN_VERSION,
            true
        );
        
        wp_localize_script('vt-scripts', 'vt_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('vt_nonce'),
            'lang' => array(
                'error' => __('حدث خطأ. يرجى المحاولة مرة أخرى.', 'video-translator'),
                'processing' => __('جاري المعالجة...', 'video-translator'),
                'completed' => __('تمت المعالجة بنجاح!', 'video-translator'),
                'download' => __('تحميل الفيديو المدبلج', 'video-translator'),
                'invalid_url' => __('يرجى إدخال رابط يوتيوب صالح', 'video-translator'),
                'select_language' => __('يرجى اختيار لغة', 'video-translator'),
            ),
        ));
    }
    
    /**
     * معالجة طلب AJAX لتحميل ومعالجة فيديو يوتيوب
     */
    public function ajax_process_youtube() {
        // التحقق من nonce
        check_ajax_referer('vt_nonce', 'nonce');
        
        // التحقق من URL يوتيوب
        $youtube_url = isset($_POST['youtube_url']) ? sanitize_text_field($_POST['youtube_url']) : '';
        
        if (empty($youtube_url)) {
            wp_send_json_error(array('message' => __('يرجى تقديم رابط يوتيوب صالح', 'video-translator')));
        }
        
        // التحقق من اللغة المستهدفة
        $target_language = isset($_POST['target_language']) ? sanitize_text_field($_POST['target_language']) : '';
        
        if (empty($target_language) || !array_key_exists($target_language, $this->languages)) {
            wp_send_json_error(array('message' => __('يرجى اختيار لغة مستهدفة صالحة', 'video-translator')));
        }
        
        // إنشاء إسم وإد فريد للمعالجة
        $process_id = uniqid();
        $temp_dir = VT_TEMP_DIR . '/' . $process_id;
        
        if (!file_exists($temp_dir)) {
            wp_mkdir_p($temp_dir);
        }
        
        $temp_video_path = $temp_dir . '/input_video.mp4';
        $temp_audio_path = $temp_dir . '/extracted_audio.mp3';
        $temp_output_audio_path = $temp_dir . '/output_audio.mp3';
        $temp_output_video_path = $temp_dir . '/output_video.mp4';
        
        try {
            // تحميل الفيديو من يوتيوب (باستخدام Python)
            $this->download_youtube_video($youtube_url, $temp_video_path);
            
            // استخراج الصوت
            $this->extract_audio($temp_video_path, $temp_audio_path);
            
            // تحويل الصوت إلى نص
            $transcribed_text = $this->transcribe_audio($temp_audio_path);
            
            // ترجمة النص
            $language_info = $this->languages[$target_language];
            $translated_text = $this->translate_text($transcribed_text, $language_info['deepl_code']);
            
            // تحويل النص إلى صوت
            $this->generate_speech($translated_text, $language_info['code'], $temp_output_audio_path);
            
            // دمج الصوت مع الفيديو
            $this->merge_audio_with_video($temp_video_path, $temp_output_audio_path, $temp_output_video_path);
            
            // إنشاء ملف في مجلد الوسائط
            $wp_upload_dir = wp_upload_dir();
            $output_filename = 'dubbed_video_' . $process_id . '.mp4';
            $output_filepath = $wp_upload_dir['path'] . '/' . $output_filename;
            
            // نسخ الملف إلى مجلد الوسائط
            copy($temp_output_video_path, $output_filepath);
            
            // إضافة الملف إلى مكتبة الوسائط
            $attachment = array(
                'guid' => $wp_upload_dir['url'] . '/' . $output_filename,
                'post_mime_type' => 'video/mp4',
                'post_title' => 'مقطع فيديو مدبلج',
                'post_content' => 'فيديو يوتيوب مدبلج ومترجم إلى ' . $language_info['name'],
                'post_status' => 'inherit'
            );
            
            $attachment_id = wp_insert_attachment($attachment, $output_filepath);
            
            // تنظيف المجلد المؤقت
            $this->cleanup_temp_dir($temp_dir);
            
            // إرجاع النتيجة الناجحة
            wp_send_json_success(array(
                'message' => __('تمت معالجة الفيديو بنجاح!', 'video-translator'),
                'video_url' => wp_get_attachment_url($attachment_id),
                'video_id' => $attachment_id,
            ));
            
        } catch (Exception $e) {
            // تنظيف المجلد المؤقت في حالة الفشل
            $this->cleanup_temp_dir($temp_dir);
            
            wp_send_json_error(array(
                'message' => $e->getMessage()
            ));
        }
    }
    
    /**
     * معالجة طلب AJAX لمعالجة فيديو مرفوع
     */
    public function ajax_process_uploaded_video() {
        // التحقق من nonce
        check_ajax_referer('vt_nonce', 'nonce');
        
        // التحقق من معرف الوسائط
        $attachment_id = isset($_POST['attachment_id']) ? intval($_POST['attachment_id']) : 0;
        
        if (empty($attachment_id)) {
            wp_send_json_error(array('message' => __('لم يتم تحديد ملف فيديو صالح', 'video-translator')));
        }
        
        // التحقق من اللغة المستهدفة
        $target_language = isset($_POST['target_language']) ? sanitize_text_field($_POST['target_language']) : '';
        
        if (empty($target_language) || !array_key_exists($target_language, $this->languages)) {
            wp_send_json_error(array('message' => __('يرجى اختيار لغة مستهدفة صالحة', 'video-translator')));
        }
        
        // الحصول على مسار الملف
        $attached_file = get_attached_file($attachment_id);
        
        if (!$attached_file || !file_exists($attached_file)) {
            wp_send_json_error(array('message' => __('لم يتم العثور على ملف الفيديو', 'video-translator')));
        }
        
        // إنشاء إسم وإد فريد للمعالجة
        $process_id = uniqid();
        $temp_dir = VT_TEMP_DIR . '/' . $process_id;
        
        if (!file_exists($temp_dir)) {
            wp_mkdir_p($temp_dir);
        }
        
        $temp_video_path = $temp_dir . '/input_video.mp4';
        $temp_audio_path = $temp_dir . '/extracted_audio.mp3';
        $temp_output_audio_path = $temp_dir . '/output_audio.mp3';
        $temp_output_video_path = $temp_dir . '/output_video.mp4';
        
        try {
            // نسخ الفيديو المرفوع للمجلد المؤقت
            copy($attached_file, $temp_video_path);
            
            // استخراج الصوت
            $this->extract_audio($temp_video_path, $temp_audio_path);
            
            // تحويل الصوت إلى نص
            $transcribed_text = $this->transcribe_audio($temp_audio_path);
            
            // ترجمة النص
            $language_info = $this->languages[$target_language];
            $translated_text = $this->translate_text($transcribed_text, $language_info['deepl_code']);
            
            // تحويل النص إلى صوت
            $this->generate_speech($translated_text, $language_info['code'], $temp_output_audio_path);
            
            // دمج الصوت مع الفيديو
            $this->merge_audio_with_video($temp_video_path, $temp_output_audio_path, $temp_output_video_path);
            
            // إنشاء ملف في مجلد الوسائط
            $wp_upload_dir = wp_upload_dir();
            $output_filename = 'dubbed_video_' . $process_id . '.mp4';
            $output_filepath = $wp_upload_dir['path'] . '/' . $output_filename;
            
            // نسخ الملف إلى مجلد الوسائط
            copy($temp_output_video_path, $output_filepath);
            
            // الحصول على معلومات الملف الأصلي
            $original_attachment = get_post($attachment_id);
            
            // إضافة الملف إلى مكتبة الوسائط
            $attachment = array(
                'guid' => $wp_upload_dir['url'] . '/' . $output_filename,
                'post_mime_type' => 'video/mp4',
                'post_title' => 'مقطع فيديو مدبلج - ' . $original_attachment->post_title,
                'post_content' => 'فيديو مدبلج ومترجم إلى ' . $language_info['name'],
                'post_status' => 'inherit'
            );
            
            $attachment_id = wp_insert_attachment($attachment, $output_filepath);
            
            // تنظيف المجلد المؤقت
            $this->cleanup_temp_dir($temp_dir);
            
            // إرجاع النتيجة الناجحة
            wp_send_json_success(array(
                'message' => __('تمت معالجة الفيديو بنجاح!', 'video-translator'),
                'video_url' => wp_get_attachment_url($attachment_id),
                'video_id' => $attachment_id,
            ));
            
        } catch (Exception $e) {
            // تنظيف المجلد المؤقت في حالة الفشل
            $this->cleanup_temp_dir($temp_dir);
            
            wp_send_json_error(array(
                'message' => $e->getMessage()
            ));
        }
    }
    
    /**
     * تنظيف الملفات المؤقتة
     */
    public function ajax_cleanup_temp_files() {
        // التحقق من nonce
        check_ajax_referer('vt_nonce', 'nonce');
        
        // التحقق من الصلاحيات
        if (!current_user_can('vt_manage_settings')) {
            wp_send_json_error(array('message' => __('ليس لديك الصلاحيات الكافية', 'video-translator')));
        }
        
        $this->cleanup_temp_dir(VT_TEMP_DIR);
        
        wp_send_json_success(array(
            'message' => __('تم تنظيف الملفات المؤقتة بنجاح', 'video-translator')
        ));
    }
    
    /**
     * تنزيل فيديو يوتيوب باستخدام python
     */
    private function download_youtube_video($youtube_url, $output_path) {
        // إنشاء ملف Python مؤقت
        $python_script = VT_TEMP_DIR . '/youtube_downloader.py';
        
        $script_content = '
import sys
import yt_dlp

def download_video(url, output_path):
    ydl_opts = {
        "format": "best[ext=mp4]/best",
        "outtmpl": output_path,
        "quiet": True,
    }
    
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])
        return True
    except Exception as e:
        print(f"Error downloading video: {str(e)}")
        return False

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python youtube_downloader.py <youtube_url> <output_path>")
        sys.exit(1)
    
    youtube_url = sys.argv[1]
    output_path = sys.argv[2]
    
    success = download_video(youtube_url, output_path)
    sys.exit(0 if success else 1)
        ';
        
        file_put_contents($python_script, $script_content);
        
        // تنفيذ البرنامج النصي
        $command = "python3 " . escapeshellarg($python_script) . " " . escapeshellarg($youtube_url) . " " . escapeshellarg($output_path);
        exec($command, $output, $return_code);
        
        // حذف الملف المؤقت
        unlink($python_script);
        
        if ($return_code !== 0 || !file_exists($output_path)) {
            throw new Exception(__('فشل تنزيل الفيديو من يوتيوب', 'video-translator'));
        }
        
        return true;
    }
    
    /**
     * استخراج الصوت من الفيديو
     */
    private function extract_audio($video_path, $audio_path) {
        $command = "ffmpeg -i " . escapeshellarg($video_path) . " -q:a 0 -map a " . escapeshellarg($audio_path) . " -y";
        exec($command, $output, $return_code);
        
        if ($return_code !== 0 || !file_exists($audio_path)) {
            throw new Exception(__('فشل استخراج الصوت من الفيديو', 'video-translator'));
        }
        
        return true;
    }
    
    /**
     * تحويل الصوت إلى نص
     */
    private function transcribe_audio($audio_path) {
        // إنشاء ملف Python مؤقت
        $python_script = VT_TEMP_DIR . '/transcriber.py';
        
        $script_content = '
import sys
import speech_recognition as sr

def transcribe_audio(audio_file):
    recognizer = sr.Recognizer()
    
    try:
        with sr.AudioFile(audio_file) as source:
            audio_data = recognizer.record(source)
            text = recognizer.recognize_google(audio_data)
            return text
    except Exception as e:
        print(f"Error transcribing audio: {str(e)}")
        return ""

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python transcriber.py <audio_path>")
        sys.exit(1)
    
    audio_path = sys.argv[1]
    transcription = transcribe_audio(audio_path)
    
    if transcription:
        print(transcription)
        sys.exit(0)
    else:
        sys.exit(1)
        ';
        
        file_put_contents($python_script, $script_content);
        
        // تنفيذ البرنامج النصي
        $command = "python3 " . escapeshellarg($python_script) . " " . escapeshellarg($audio_path);
        exec($command, $output, $return_code);
        
        // حذف الملف المؤقت
        unlink($python_script);
        
        if ($return_code !== 0 || empty($output)) {
            throw new Exception(__('فشل تحويل الصوت إلى نص', 'video-translator'));
        }
        
        return implode("\n", $output);
    }
    
    /**
     * ترجمة النص
     */
    private function translate_text($text, $target_language) {
        // التحقق من وجود مفتاح DeepL
        $deepl_api_key = isset($this->settings['deepl_api_key']) ? $this->settings['deepl_api_key'] : '';
        
        if (!empty($deepl_api_key)) {
            // استخدام واجهة برمجة DeepL
            $url = 'https://api-free.deepl.com/v2/translate';
            
            $data = array(
                'auth_key' => $deepl_api_key,
                'text' => $text,
                'target_lang' => $target_language,
            );
            
            $response = wp_remote_post($url, array(
                'body' => $data,
                'timeout' => 30,
            ));
            
            if (is_wp_error($response)) {
                throw new Exception(__('فشل الاتصال بخدمة الترجمة', 'video-translator'));
            }
            
            $body = wp_remote_retrieve_body($response);
            $result = json_decode($body, true);
            
            if (isset($result['translations'][0]['text'])) {
                return $result['translations'][0]['text'];
            }
        }
        
        // استخدام ترجمة احتياطية (يمكن إضافة Google Translate هنا)
        return $this->fallback_translation($text, $target_language);
    }
    
    /**
     * ترجمة احتياطية
     */
    private function fallback_translation($text, $target_language) {
        // قم بإضافة طريقة ترجمة احتياطية أخرى هنا إذا لزم الأمر
        // حاليًا نعيد النص كما هو
        
        // يمكن استخدام Google Translate API هنا
        
        throw new Exception(__('لم يتم تهيئة خدمة الترجمة بشكل صحيح. يرجى إضافة مفتاح API في إعدادات الإضافة.', 'video-translator'));
    }
    
    /**
     * تحويل النص إلى صوت
     */
    private function generate_speech($text, $language_code, $output_path) {
        // إنشاء ملف Python مؤقت
        $python_script = VT_TEMP_DIR . '/tts.py';
        
        $script_content = '
import sys
from gtts import gTTS

def text_to_speech(text, language, output_path):
    try:
        tts = gTTS(text=text, lang=language, slow=False)
        tts.save(output_path)
        return True
    except Exception as e:
        print(f"Error generating speech: {str(e)}")
        return False

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python tts.py <text> <language> <output_path>")
        sys.exit(1)
    
    text = sys.argv[1]
    language = sys.argv[2]
    output_path = sys.argv[3]
    
    success = text_to_speech(text, language, output_path)
    sys.exit(0 if success else 1)
        ';
        
        file_put_contents($python_script, $script_content);
        
        // كتابة النص إلى ملف مؤقت
        $text_file = VT_TEMP_DIR . '/temp_text.txt';
        file_put_contents($text_file, $text);
        
        // تنفيذ البرنامج النصي
        $command = "python3 " . escapeshellarg($python_script) . " " . escapeshellarg($text) . " " . escapeshellarg($language_code) . " " . escapeshellarg($output_path);
        exec($command, $output, $return_code);
        
        // حذف الملفات المؤقتة
        unlink($python_script);
        unlink($text_file);
        
        if ($return_code !== 0 || !file_exists($output_path)) {
            throw new Exception(__('فشل تحويل النص إلى صوت', 'video-translator'));
        }
        
        return true;
    }
    
    /**
     * دمج الصوت مع الفيديو
     */
    private function merge_audio_with_video($video_path, $audio_path, $output_path) {
        $command = "ffmpeg -i " . escapeshellarg($video_path) . " -i " . escapeshellarg($audio_path) . " -c:v copy -map 0:v:0 -map 1:a:0 " . escapeshellarg($output_path) . " -y";
        exec($command, $output, $return_code);
        
        if ($return_code !== 0 || !file_exists($output_path)) {
            throw new Exception(__('فشل دمج الصوت مع الفيديو', 'video-translator'));
        }
        
        return true;
    }
    
    /**
     * تنظيف المجلد المؤقت
     */
    private function cleanup_temp_dir($dir) {
        if (is_dir($dir)) {
            $objects = scandir($dir);
            foreach ($objects as $object) {
                if ($object != "." && $object != "..") {
                    if (is_dir($dir . "/" . $object)) {
                        $this->cleanup_temp_dir($dir . "/" . $object);
                    } else {
                        unlink($dir . "/" . $object);
                    }
                }
            }
            rmdir($dir);
        }
    }
    
    /**
     * الحصول على اللغات المدعومة
     */
    public function get_languages() {
        return $this->languages;
    }
}