<?php
/**
 * فئة إدارة الإضافة في لوحة التحكم
 */
class Video_Translator_Admin {
    /**
     * إعدادات الإضافة
     */
    private $settings;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->settings = get_option('vt_settings', array());
        
        // إضافة قوائم الإدارة
        add_action('admin_menu', array($this, 'add_admin_menu'));
        
        // تسجيل الإعدادات
        add_action('admin_init', array($this, 'register_settings'));
        
        // إضافة الأصول (CSS و JS)
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        
        // إضافة رابط الإعدادات في صفحة الإضافات
        add_filter('plugin_action_links_video-translator/video-translator.php', array($this, 'add_settings_link'));
        
        // إضافة دعم تحميل الفيديو في نموذج الوسائط
        add_filter('plupload_default_settings', array($this, 'plupload_settings'), 10);
        add_filter('upload_mimes', array($this, 'add_mime_types'), 1, 1);
    }
    
    /**
     * إضافة قائمة الإدارة
     */
    public function add_admin_menu() {
        add_menu_page(
            __('مترجم ومدبلج الفيديو', 'video-translator'),
            __('مترجم الفيديو', 'video-translator'),
            'vt_manage_settings',
            'video-translator',
            array($this, 'render_settings_page'),
            'dashicons-video-alt3',
            30
        );
        
        add_submenu_page(
            'video-translator',
            __('إعدادات', 'video-translator'),
            __('إعدادات', 'video-translator'),
            'vt_manage_settings',
            'video-translator',
            array($this, 'render_settings_page')
        );
        
        add_submenu_page(
            'video-translator',
            __('معالجة فيديو جديد', 'video-translator'),
            __('معالجة فيديو جديد', 'video-translator'),
            'edit_posts',
            'vt-process-video',
            array($this, 'render_process_page')
        );
        
        // إضافة صفحة إدارة الاشتراكات
        add_submenu_page(
            'video-translator',
            __('إدارة الاشتراكات', 'video-translator'),
            __('الاشتراكات', 'video-translator'),
            'vt_manage_subscriptions',
            'vt-subscriptions',
            array($this, 'render_subscriptions_page')
        );
    }
    
    /**
     * عرض صفحة إدارة الاشتراكات
     */
    public function render_subscriptions_page() {
        // التحقق من وجود كلاس إدارة الاشتراكات
        if (class_exists('Video_Translator_Subscriptions')) {
            $subscriptions = new Video_Translator_Subscriptions();
            $subscriptions->render_admin_page();
        } else {
            echo '<div class="wrap">';
            echo '<h1>' . esc_html__('إدارة الاشتراكات', 'video-translator') . '</h1>';
            echo '<div class="notice notice-error"><p>' . esc_html__('وحدة الاشتراكات غير متوفرة!', 'video-translator') . '</p></div>';
            echo '</div>';
        }
    }
    
    /**
     * تسجيل إعدادات الإضافة
     */
    public function register_settings() {
        register_setting('vt_settings', 'vt_settings');
        
        // قسم الإعدادات العامة
        add_settings_section(
            'vt_general_section',
            __('إعدادات عامة', 'video-translator'),
            array($this, 'render_general_section'),
            'video-translator'
        );
        
        add_settings_field(
            'deepl_api_key',
            __('مفتاح API لـ DeepL', 'video-translator'),
            array($this, 'render_deepl_api_key_field'),
            'video-translator',
            'vt_general_section'
        );
        
        add_settings_field(
            'elevenlabs_api_key',
            __('مفتاح API لـ ElevenLabs', 'video-translator'),
            array($this, 'render_elevenlabs_api_key_field'),
            'video-translator',
            'vt_general_section'
        );
        
        add_settings_field(
            'default_language',
            __('اللغة الافتراضية', 'video-translator'),
            array($this, 'render_default_language_field'),
            'video-translator',
            'vt_general_section'
        );
        
        add_settings_field(
            'max_upload_size',
            __('الحد الأقصى لحجم التحميل (ميجابايت)', 'video-translator'),
            array($this, 'render_max_upload_size_field'),
            'video-translator',
            'vt_general_section'
        );
        
        add_settings_field(
            'enable_youtube',
            __('تفعيل دعم يوتيوب', 'video-translator'),
            array($this, 'render_enable_youtube_field'),
            'video-translator',
            'vt_general_section'
        );
        
        add_settings_field(
            'enable_upload',
            __('تفعيل تحميل الفيديو', 'video-translator'),
            array($this, 'render_enable_upload_field'),
            'video-translator',
            'vt_general_section'
        );
        
        add_settings_field(
            'delete_temp_files',
            __('حذف الملفات المؤقتة عند إلغاء تفعيل الإضافة', 'video-translator'),
            array($this, 'render_delete_temp_files_field'),
            'video-translator',
            'vt_general_section'
        );
        
        // قسم إعدادات الاشتراكات
        add_settings_section(
            'vt_subscription_section',
            __('إعدادات الاشتراكات', 'video-translator'),
            array($this, 'render_subscription_section'),
            'video-translator'
        );
        
        add_settings_field(
            'enable_subscription',
            __('تفعيل نظام الاشتراكات', 'video-translator'),
            array($this, 'render_enable_subscription_field'),
            'video-translator',
            'vt_subscription_section'
        );
        
        add_settings_field(
            'enable_free_tier',
            __('تفعيل الطبقة المجانية', 'video-translator'),
            array($this, 'render_enable_free_tier_field'),
            'video-translator',
            'vt_subscription_section'
        );
        
        add_settings_field(
            'free_videos_limit',
            __('عدد الفيديوهات المجانية', 'video-translator'),
            array($this, 'render_free_videos_limit_field'),
            'video-translator',
            'vt_subscription_section'
        );
        
        add_settings_field(
            'free_duration_limit',
            __('حد المدة للفيديوهات المجانية (دقائق)', 'video-translator'),
            array($this, 'render_free_duration_limit_field'),
            'video-translator',
            'vt_subscription_section'
        );
        
        add_settings_field(
            'premium_features',
            __('الميزات المدفوعة', 'video-translator'),
            array($this, 'render_premium_features_field'),
            'video-translator',
            'vt_subscription_section'
        );
    }
    
    /**
     * عرض صفحة الإعدادات
     */
    public function render_settings_page() {
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('إعدادات مترجم ومدبلج الفيديو', 'video-translator'); ?></h1>
            
            <form method="post" action="options.php">
                <?php
                settings_fields('vt_settings');
                do_settings_sections('video-translator');
                submit_button();
                ?>
            </form>
            
            <hr>
            
            <h2><?php echo esc_html__('تنظيف الملفات المؤقتة', 'video-translator'); ?></h2>
            <p><?php echo esc_html__('انقر على الزر أدناه لحذف جميع الملفات المؤقتة المخزنة بواسطة الإضافة.', 'video-translator'); ?></p>
            <button id="vt-cleanup-temp" class="button button-secondary"><?php echo esc_html__('تنظيف الملفات المؤقتة', 'video-translator'); ?></button>
            <span id="vt-cleanup-status"></span>
        </div>
        <?php
    }
    
    /**
     * عرض صفحة معالجة الفيديو
     */
    public function render_process_page() {
        // الحصول على كائن الفيديو
        $video_translator = new Video_Translator();
        $languages = $video_translator->get_languages();
        
        // الحصول على الإعدادات
        $settings = get_option('vt_settings', array());
        $default_language = isset($settings['default_language']) ? $settings['default_language'] : 'ar';
        $enable_youtube = isset($settings['enable_youtube']) ? $settings['enable_youtube'] : 'yes';
        $enable_upload = isset($settings['enable_upload']) ? $settings['enable_upload'] : 'yes';
        
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('معالجة فيديو جديد', 'video-translator'); ?></h1>
            
            <div class="vt-tabs">
                <ul class="vt-tab-nav">
                    <?php if ($enable_youtube === 'yes') : ?>
                        <li class="vt-tab-link active" data-tab="vt-youtube-tab"><?php echo esc_html__('فيديو يوتيوب', 'video-translator'); ?></li>
                    <?php endif; ?>
                    
                    <?php if ($enable_upload === 'yes') : ?>
                        <li class="vt-tab-link <?php echo ($enable_youtube !== 'yes') ? 'active' : ''; ?>" data-tab="vt-upload-tab"><?php echo esc_html__('تحميل فيديو', 'video-translator'); ?></li>
                    <?php endif; ?>
                </ul>
                
                <div class="vt-tab-content">
                    <?php if ($enable_youtube === 'yes') : ?>
                        <div id="vt-youtube-tab" class="vt-tab-pane active">
                            <h2><?php echo esc_html__('معالجة فيديو يوتيوب', 'video-translator'); ?></h2>
                            
                            <div class="vt-form-group">
                                <label for="vt-youtube-url"><?php echo esc_html__('رابط فيديو يوتيوب:', 'video-translator'); ?></label>
                                <input type="text" id="vt-youtube-url" class="regular-text" placeholder="https://www.youtube.com/watch?v=...">
                            </div>
                            
                            <div class="vt-form-group">
                                <label for="vt-youtube-language"><?php echo esc_html__('اللغة المستهدفة:', 'video-translator'); ?></label>
                                <select id="vt-youtube-language">
                                    <?php foreach ($languages as $code => $language) : ?>
                                        <option value="<?php echo esc_attr($code); ?>" <?php selected($code, $default_language); ?>>
                                            <?php echo esc_html($language['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="vt-form-group">
                                <button id="vt-process-youtube" class="button button-primary"><?php echo esc_html__('معالجة الفيديو', 'video-translator'); ?></button>
                                <span id="vt-youtube-status"></span>
                            </div>
                            
                            <div id="vt-youtube-result" class="vt-result" style="display:none;">
                                <h3><?php echo esc_html__('الفيديو المدبلج:', 'video-translator'); ?></h3>
                                <div class="vt-video-container"></div>
                                <p><a href="#" class="button vt-download-link" target="_blank"><?php echo esc_html__('تحميل الفيديو', 'video-translator'); ?></a></p>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($enable_upload === 'yes') : ?>
                        <div id="vt-upload-tab" class="vt-tab-pane <?php echo ($enable_youtube !== 'yes') ? 'active' : ''; ?>">
                            <h2><?php echo esc_html__('تحميل ومعالجة فيديو', 'video-translator'); ?></h2>
                            
                            <div class="vt-form-group">
                                <label for="vt-upload-video"><?php echo esc_html__('اختر ملف فيديو:', 'video-translator'); ?></label>
                                <button id="vt-upload-video" class="button"><?php echo esc_html__('اختر فيديو', 'video-translator'); ?></button>
                                <div id="vt-selected-file"></div>
                            </div>
                            
                            <div class="vt-form-group">
                                <label for="vt-upload-language"><?php echo esc_html__('اللغة المستهدفة:', 'video-translator'); ?></label>
                                <select id="vt-upload-language">
                                    <?php foreach ($languages as $code => $language) : ?>
                                        <option value="<?php echo esc_attr($code); ?>" <?php selected($code, $default_language); ?>>
                                            <?php echo esc_html($language['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="vt-form-group">
                                <button id="vt-process-upload" class="button button-primary" disabled><?php echo esc_html__('معالجة الفيديو', 'video-translator'); ?></button>
                                <span id="vt-upload-status"></span>
                            </div>
                            
                            <div id="vt-upload-result" class="vt-result" style="display:none;">
                                <h3><?php echo esc_html__('الفيديو المدبلج:', 'video-translator'); ?></h3>
                                <div class="vt-video-container"></div>
                                <p><a href="#" class="button vt-download-link" target="_blank"><?php echo esc_html__('تحميل الفيديو', 'video-translator'); ?></a></p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * عرض قسم الإعدادات العامة
     */
    public function render_general_section() {
        echo '<p>' . esc_html__('قم بتهيئة الإعدادات العامة للإضافة.', 'video-translator') . '</p>';
    }
    
    /**
     * عرض حقل مفتاح API لـ DeepL
     */
    public function render_deepl_api_key_field() {
        $value = isset($this->settings['deepl_api_key']) ? $this->settings['deepl_api_key'] : '';
        echo '<input type="text" name="vt_settings[deepl_api_key]" value="' . esc_attr($value) . '" class="regular-text">';
        echo '<p class="description">' . esc_html__('أدخل مفتاح API لخدمة DeepL للترجمة. الحصول على مفتاح: https://www.deepl.com/pro-api', 'video-translator') . '</p>';
    }
    
    /**
     * عرض حقل مفتاح API لـ ElevenLabs
     */
    public function render_elevenlabs_api_key_field() {
        $value = isset($this->settings['elevenlabs_api_key']) ? $this->settings['elevenlabs_api_key'] : '';
        echo '<input type="text" name="vt_settings[elevenlabs_api_key]" value="' . esc_attr($value) . '" class="regular-text">';
        echo '<p class="description">' . esc_html__('أدخل مفتاح API لخدمة ElevenLabs لتحويل النص إلى صوت. الحصول على مفتاح: https://elevenlabs.io', 'video-translator') . '</p>';
    }
    
    /**
     * عرض حقل اللغة الافتراضية
     */
    public function render_default_language_field() {
        $value = isset($this->settings['default_language']) ? $this->settings['default_language'] : 'ar';
        
        // الحصول على كائن الفيديو
        $video_translator = new Video_Translator();
        $languages = $video_translator->get_languages();
        
        echo '<select name="vt_settings[default_language]">';
        foreach ($languages as $code => $language) {
            echo '<option value="' . esc_attr($code) . '" ' . selected($value, $code, false) . '>' . esc_html($language['name']) . '</option>';
        }
        echo '</select>';
        echo '<p class="description">' . esc_html__('اختر اللغة الافتراضية للترجمة.', 'video-translator') . '</p>';
    }
    
    /**
     * عرض حقل الحد الأقصى لحجم التحميل
     */
    public function render_max_upload_size_field() {
        $value = isset($this->settings['max_upload_size']) ? intval($this->settings['max_upload_size']) : 20;
        echo '<input type="number" name="vt_settings[max_upload_size]" value="' . esc_attr($value) . '" class="small-text">';
        echo '<p class="description">' . esc_html__('الحد الأقصى لحجم ملف الفيديو المرفوع بالميجابايت.', 'video-translator') . '</p>';
    }
    
    /**
     * عرض حقل تفعيل دعم يوتيوب
     */
    public function render_enable_youtube_field() {
        $value = isset($this->settings['enable_youtube']) ? $this->settings['enable_youtube'] : 'yes';
        echo '<label>';
        echo '<input type="checkbox" name="vt_settings[enable_youtube]" value="yes" ' . checked($value, 'yes', false) . '>';
        echo esc_html__('تفعيل دعم تحميل ومعالجة فيديوهات يوتيوب', 'video-translator');
        echo '</label>';
    }
    
    /**
     * عرض حقل تفعيل تحميل الفيديو
     */
    public function render_enable_upload_field() {
        $value = isset($this->settings['enable_upload']) ? $this->settings['enable_upload'] : 'yes';
        echo '<label>';
        echo '<input type="checkbox" name="vt_settings[enable_upload]" value="yes" ' . checked($value, 'yes', false) . '>';
        echo esc_html__('تفعيل تحميل ومعالجة ملفات الفيديو المحلية', 'video-translator');
        echo '</label>';
    }
    
    /**
     * عرض حقل حذف الملفات المؤقتة
     */
    public function render_delete_temp_files_field() {
        $value = isset($this->settings['delete_temp_files']) ? $this->settings['delete_temp_files'] : 'yes';
        echo '<label>';
        echo '<input type="checkbox" name="vt_settings[delete_temp_files]" value="yes" ' . checked($value, 'yes', false) . '>';
        echo esc_html__('حذف الملفات المؤقتة عند إلغاء تفعيل الإضافة', 'video-translator');
        echo '</label>';
    }
    
    /**
     * عرض قسم إعدادات الاشتراكات
     */
    public function render_subscription_section() {
        echo '<p>' . esc_html__('قم بتهيئة إعدادات نظام الاشتراكات والميزات المدفوعة.', 'video-translator') . '</p>';
        
        echo '<p><strong>ملاحظة هامة:</strong> ' . esc_html__('يمكنك إدارة باقات الاشتراك من صفحة "الاشتراكات" في القائمة الجانبية.', 'video-translator') . '</p>';
        
        // عرض رابط للانتقال إلى صفحة الاشتراكات
        if (class_exists('Video_Translator_Subscriptions')) {
            echo '<p><a href="' . esc_url(admin_url('admin.php?page=vt-subscriptions')) . '" class="button button-secondary">' . esc_html__('إدارة باقات الاشتراك', 'video-translator') . '</a></p>';
        }
    }
    
    /**
     * عرض حقل تفعيل نظام الاشتراكات
     */
    public function render_enable_subscription_field() {
        $value = isset($this->settings['enable_subscription']) ? $this->settings['enable_subscription'] : 'yes';
        echo '<label>';
        echo '<input type="checkbox" name="vt_settings[enable_subscription]" value="yes" ' . checked($value, 'yes', false) . '>';
        echo esc_html__('تفعيل نظام الاشتراكات والمميزات المدفوعة', 'video-translator');
        echo '</label>';
        echo '<p class="description">' . esc_html__('تفعيل هذا الخيار سيتيح استخدام نظام الاشتراكات والميزات المدفوعة في الإضافة.', 'video-translator') . '</p>';
    }
    
    /**
     * عرض حقل تفعيل الطبقة المجانية
     */
    public function render_enable_free_tier_field() {
        $value = isset($this->settings['enable_free_tier']) ? $this->settings['enable_free_tier'] : 'yes';
        echo '<label>';
        echo '<input type="checkbox" name="vt_settings[enable_free_tier]" value="yes" ' . checked($value, 'yes', false) . '>';
        echo esc_html__('تفعيل الطبقة المجانية', 'video-translator');
        echo '</label>';
        echo '<p class="description">' . esc_html__('تفعيل هذا الخيار سيتيح للمستخدمين غير المشتركين استخدام الإضافة بشكل محدود.', 'video-translator') . '</p>';
    }
    
    /**
     * عرض حقل عدد الفيديوهات المجانية
     */
    public function render_free_videos_limit_field() {
        $value = isset($this->settings['free_videos_limit']) ? intval($this->settings['free_videos_limit']) : 3;
        echo '<input type="number" name="vt_settings[free_videos_limit]" value="' . esc_attr($value) . '" class="small-text" min="0">';
        echo '<p class="description">' . esc_html__('الحد الأقصى لعدد الفيديوهات التي يمكن للمستخدم غير المشترك معالجتها. استخدم 0 لتعطيل الفيديوهات المجانية تماماً.', 'video-translator') . '</p>';
    }
    
    /**
     * عرض حقل حد المدة للفيديوهات المجانية
     */
    public function render_free_duration_limit_field() {
        $value = isset($this->settings['free_duration_limit']) ? intval($this->settings['free_duration_limit']) : 5;
        echo '<input type="number" name="vt_settings[free_duration_limit]" value="' . esc_attr($value) . '" class="small-text" min="0">';
        echo '<p class="description">' . esc_html__('الحد الأقصى لمدة الفيديو بالدقائق للمستخدم غير المشترك.', 'video-translator') . '</p>';
    }
    
    /**
     * عرض حقل الميزات المدفوعة
     */
    public function render_premium_features_field() {
        $premium_features = isset($this->settings['premium_features']) ? (array) $this->settings['premium_features'] : array('elevenlabs_voices', 'lip_sync');
        
        echo '<fieldset>';
        echo '<legend class="screen-reader-text">' . esc_html__('الميزات المدفوعة', 'video-translator') . '</legend>';
        
        // الميزات المتاحة
        $available_features = array(
            'elevenlabs_voices' => __('أصوات ElevenLabs المتقدمة', 'video-translator'),
            'lip_sync' => __('مزامنة الشفاه (Lip Sync)', 'video-translator'),
            'download_video' => __('تحميل الفيديو المدبلج', 'video-translator'),
            'youtube_support' => __('دعم فيديوهات يوتيوب', 'video-translator'),
            'upload_support' => __('دعم تحميل الفيديوهات', 'video-translator'),
        );
        
        foreach ($available_features as $feature_id => $feature_name) {
            echo '<label>';
            echo '<input type="checkbox" name="vt_settings[premium_features][]" value="' . esc_attr($feature_id) . '" ' . checked(in_array($feature_id, $premium_features), true, false) . '>';
            echo esc_html($feature_name);
            echo '</label><br>';
        }
        
        echo '</fieldset>';
        echo '<p class="description">' . esc_html__('حدد الميزات التي ستكون متاحة فقط للمستخدمين المشتركين.', 'video-translator') . '</p>';
    }
    
    /**
     * تضمين ملفات JS و CSS للإدارة
     */
    public function enqueue_admin_scripts($hook) {
        // التحقق من أن الصفحة هي صفحة الإعدادات أو معالجة الفيديو
        if ($hook !== 'toplevel_page_video-translator' && $hook !== 'video-translator_page_vt-process-video') {
            return;
        }
        
        wp_enqueue_media();
        
        wp_enqueue_style(
            'vt-admin-styles', 
            VT_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            VT_PLUGIN_VERSION
        );
        
        wp_enqueue_script(
            'vt-admin-scripts',
            VT_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery', 'media-upload'),
            VT_PLUGIN_VERSION,
            true
        );
        
        wp_localize_script('vt-admin-scripts', 'vt_admin', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('vt_nonce'),
            'lang' => array(
                'error' => __('حدث خطأ. يرجى المحاولة مرة أخرى.', 'video-translator'),
                'processing' => __('جاري المعالجة...', 'video-translator'),
                'completed' => __('تمت المعالجة بنجاح!', 'video-translator'),
                'download' => __('تحميل الفيديو', 'video-translator'),
                'select_file' => __('اختر ملف فيديو', 'video-translator'),
                'file_selected' => __('تم اختيار الملف:', 'video-translator'),
                'invalid_url' => __('يرجى إدخال رابط يوتيوب صالح', 'video-translator'),
                'select_language' => __('يرجى اختيار لغة', 'video-translator'),
                'no_file' => __('يرجى اختيار ملف فيديو', 'video-translator'),
                'cleaning' => __('جاري تنظيف الملفات المؤقتة...', 'video-translator'),
                'clean_completed' => __('تم تنظيف الملفات المؤقتة بنجاح.', 'video-translator'),
            ),
        ));
    }
    
    /**
     * إضافة رابط الإعدادات في صفحة الإضافات
     */
    public function add_settings_link($links) {
        $settings_link = '<a href="' . admin_url('admin.php?page=video-translator') . '">' . __('الإعدادات', 'video-translator') . '</a>';
        array_unshift($links, $settings_link);
        return $links;
    }
    
    /**
     * إعدادات Plupload
     */
    public function plupload_settings($settings) {
        $max_upload_size = isset($this->settings['max_upload_size']) ? intval($this->settings['max_upload_size']) : 20;
        $max_file_size = $max_upload_size * 1024 * 1024;
        
        $settings['filters']['max_file_size'] = $max_file_size . 'b';
        
        return $settings;
    }
    
    /**
     * إضافة أنواع MIME للفيديو
     */
    public function add_mime_types($mimes) {
        $mimes['mp4'] = 'video/mp4';
        $mimes['webm'] = 'video/webm';
        $mimes['avi'] = 'video/avi';
        $mimes['mov'] = 'video/quicktime';
        
        return $mimes;
    }
}