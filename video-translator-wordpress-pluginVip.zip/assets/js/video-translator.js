/**
 * JavaScript الرئيسي للإضافة في الواجهة الأمامية
 */
(function($) {
    'use strict';
    
    // قائمة الميزات المدفوعة الحالية
    let premiumFeatures = [];
    
    // حالة تسجيل الدخول
    let isUserLoggedIn = false;
    
    // تفعيل نظام الاشتراكات
    let subscriptionEnabled = false;
    
    // تهيئة المكونات عند تحميل الصفحة
    $(document).ready(function() {
        // تهيئة الميزات المدفوعة
        if (typeof vt_frontend !== 'undefined') {
            premiumFeatures = vt_frontend.premium_features || [];
            isUserLoggedIn = vt_frontend.is_user_logged_in || false;
            subscriptionEnabled = vt_frontend.subscription_enabled || false;
        }
        
        initYoutubeForm();
        initUploadForm();
        initTabs();
        initSubscriptionButtons();
    });
    
    /**
     * تهيئة نموذج فيديو يوتيوب
     */
    function initYoutubeForm() {
        // نموذج يوتيوب المستقل
        $('#vt-process-youtube-front').on('click', function(e) {
            e.preventDefault();
            processYoutubeVideo(
                $('#vt-youtube-url-front').val(),
                $('#vt-youtube-language-front').val(),
                $('#vt-youtube-status-front'),
                $('#vt-youtube-result-front')
            );
        });
        
        // نموذج يوتيوب في النموذج المدمج
        $('#vt-process-youtube-combined').on('click', function(e) {
            e.preventDefault();
            processYoutubeVideo(
                $('#vt-youtube-url-combined').val(),
                $('#vt-youtube-language-combined').val(),
                $('#vt-youtube-status-combined'),
                $('#vt-youtube-result-combined')
            );
        });
    }
    
    /**
     * تهيئة نموذج تحميل الفيديو
     */
    function initUploadForm() {
        // نموذج التحميل المستقل
        $('#vt-upload-video-front').on('click', function(e) {
            e.preventDefault();
            openMediaLibrary($('#vt-selected-file-front'), $('#vt-process-upload-front'));
        });
        
        $('#vt-process-upload-front').on('click', function(e) {
            e.preventDefault();
            let attachmentId = $(this).data('attachment-id');
            processUploadedVideo(
                attachmentId,
                $('#vt-upload-language-front').val(),
                $('#vt-upload-status-front'),
                $('#vt-upload-result-front')
            );
        });
        
        // نموذج التحميل في النموذج المدمج
        $('#vt-upload-video-combined').on('click', function(e) {
            e.preventDefault();
            openMediaLibrary($('#vt-selected-file-combined'), $('#vt-process-upload-combined'));
        });
        
        $('#vt-process-upload-combined').on('click', function(e) {
            e.preventDefault();
            let attachmentId = $(this).data('attachment-id');
            processUploadedVideo(
                attachmentId,
                $('#vt-upload-language-combined').val(),
                $('#vt-upload-status-combined'),
                $('#vt-upload-result-combined')
            );
        });
    }
    
    /**
     * تهيئة علامات التبويب
     */
    function initTabs() {
        $('.vt-tab-link').on('click', function() {
            let tabId = $(this).data('tab');
            
            // إزالة الكلاس النشط من جميع علامات التبويب وإضافته للعلامة المحددة
            $('.vt-tab-link').removeClass('active');
            $(this).addClass('active');
            
            // إخفاء جميع المحتويات وإظهار المحتوى المحدد
            $('.vt-tab-pane').removeClass('active');
            $('#' + tabId).addClass('active');
            
            return false;
        });
    }
    
    /**
     * تهيئة أزرار الاشتراك
     */
    function initSubscriptionButtons() {
        $('.vt-purchase-button, .vt-free-button').on('click', function(e) {
            e.preventDefault();
            
            let planId = $(this).data('plan-id');
            let redirectUrl = $(this).data('redirect');
            
            if (planId) {
                purchaseSubscription(planId, redirectUrl);
            }
        });
    }
    
    /**
     * معالجة شراء الاشتراك
     */
    function purchaseSubscription(planId, redirectUrl) {
        $.ajax({
            url: vt_frontend.ajax_url,
            type: 'POST',
            data: {
                action: 'vt_purchase_subscription',
                plan_id: planId,
                redirect_url: redirectUrl,
                nonce: vt_frontend.nonce
            },
            beforeSend: function() {
                // إظهار رسالة جاري المعالجة
            },
            success: function(response) {
                if (response.success) {
                    if (response.data.redirect) {
                        window.location.href = response.data.redirect;
                    } else {
                        alert(response.data.message);
                        if (redirectUrl) {
                            window.location.href = redirectUrl;
                        } else {
                            window.location.reload();
                        }
                    }
                } else {
                    alert(response.data.message);
                }
            },
            error: function() {
                alert(vt_frontend.messages.error);
            }
        });
    }
    
    /**
     * فتح مكتبة الوسائط لاختيار فيديو
     */
    function openMediaLibrary($selectedFileElement, $processButton, callback) {
        // إذا كان هناك frame سابق، استخدمه
        if (window.vt_upload_frame) {
            window.vt_upload_frame.open();
            return;
        }
        
        // إنشاء frame جديد
        window.vt_upload_frame = wp.media({
            title: vt_frontend.messages.select_file,
            button: {
                text: vt_frontend.messages.select_file
            },
            multiple: false,
            library: {
                type: 'video'
            }
        });
        
        // عند اختيار فيديو
        window.vt_upload_frame.on('select', function() {
            let attachment = window.vt_upload_frame.state().get('selection').first().toJSON();
            
            // عرض اسم الملف المختار
            $selectedFileElement.html('<strong>' + vt_frontend.messages.file_selected + '</strong> ' + attachment.filename);
            
            // تخزين معرف الملف وتفعيل زر المعالجة
            $processButton.data('attachment-id', attachment.id).prop('disabled', false);
            
            // استدعاء callback إذا كان موجوداً
            if (typeof callback === 'function') {
                callback(attachment);
            }
        });
        
        // فتح النافذة
        window.vt_upload_frame.open();
    }
    
    /**
     * معالجة فيديو يوتيوب
     */
    function processYoutubeVideo(youtubeUrl, targetLanguage, $statusElement, $resultElement) {
        // التحقق من المدخلات
        if (!youtubeUrl) {
            alert(vt_frontend.messages.invalid_url);
            return;
        }
        
        if (!targetLanguage) {
            alert(vt_frontend.messages.select_language);
            return;
        }
        
        // التحقق من صلاحية استخدام الميزة
        if (subscriptionEnabled && !canUseFeature('youtube_support')) {
            alert(vt_frontend.messages.subscription_required);
            return;
        }
        
        // إرسال الطلب
        $.ajax({
            url: vt_frontend.ajax_url,
            type: 'POST',
            data: {
                action: 'vt_process_youtube',
                youtube_url: youtubeUrl,
                language: targetLanguage,
                nonce: vt_frontend.nonce
            },
            beforeSend: function() {
                $statusElement.text(vt_frontend.messages.processing);
                $resultElement.hide();
            },
            success: function(response) {
                if (response.success) {
                    $statusElement.text(vt_frontend.messages.completed);
                    
                    // عرض الفيديو
                    $resultElement.find('.vt-video-container').html('<video controls width="100%"><source src="' + response.data.video_url + '" type="video/mp4"></video>');
                    
                    // تحديث رابط التحميل
                    $resultElement.find('.vt-download-link').attr('href', response.data.download_url);
                    
                    $resultElement.show();
                    
                    // تحديث بيانات المستخدم
                    updateUserUsage();
                } else {
                    if (response.data.code === 'subscription_required') {
                        $statusElement.text(vt_frontend.messages.subscription_required);
                    } else {
                        $statusElement.text(response.data.message);
                    }
                }
            },
            error: function() {
                $statusElement.text(vt_frontend.messages.error);
            }
        });
    }
    
    /**
     * معالجة فيديو مرفوع
     */
    function processUploadedVideo(attachmentId, targetLanguage, $statusElement, $resultElement) {
        // التحقق من المدخلات
        if (!attachmentId) {
            alert(vt_frontend.messages.no_file);
            return;
        }
        
        if (!targetLanguage) {
            alert(vt_frontend.messages.select_language);
            return;
        }
        
        // التحقق من صلاحية استخدام الميزة
        if (subscriptionEnabled && !canUseFeature('upload_support')) {
            alert(vt_frontend.messages.subscription_required);
            return;
        }
        
        // إرسال الطلب
        $.ajax({
            url: vt_frontend.ajax_url,
            type: 'POST',
            data: {
                action: 'vt_process_upload',
                attachment_id: attachmentId,
                language: targetLanguage,
                nonce: vt_frontend.nonce
            },
            beforeSend: function() {
                $statusElement.text(vt_frontend.messages.processing);
                $resultElement.hide();
            },
            success: function(response) {
                if (response.success) {
                    $statusElement.text(vt_frontend.messages.completed);
                    
                    // عرض الفيديو
                    $resultElement.find('.vt-video-container').html('<video controls width="100%"><source src="' + response.data.video_url + '" type="video/mp4"></video>');
                    
                    // تحديث رابط التحميل
                    $resultElement.find('.vt-download-link').attr('href', response.data.download_url);
                    
                    $resultElement.show();
                    
                    // تحديث بيانات المستخدم
                    updateUserUsage();
                } else {
                    if (response.data.code === 'subscription_required') {
                        $statusElement.text(vt_frontend.messages.subscription_required);
                    } else {
                        $statusElement.text(response.data.message);
                    }
                }
            },
            error: function() {
                $statusElement.text(vt_frontend.messages.error);
            }
        });
    }
    
    /**
     * التحقق من إمكانية استخدام ميزة معينة
     */
    function canUseFeature(feature) {
        // إذا كان نظام الاشتراكات معطل، السماح بالوصول للجميع
        if (!subscriptionEnabled) {
            return true;
        }
        
        // التحقق إذا كانت الميزة مدفوعة
        if ($.inArray(feature, premiumFeatures) === -1) {
            return true; // ليست ميزة مدفوعة
        }
        
        // إذا لم يكن المستخدم مسجلاً، منع الوصول
        if (!isUserLoggedIn) {
            return false;
        }
        
        // سنفترض أن المستخدم لديه وصول للميزة حتى يتم التحقق من الخادم
        return true;
    }
    
    /**
     * تحديث بيانات استخدام المستخدم
     */
    function updateUserUsage() {
        if (isUserLoggedIn) {
            $.ajax({
                url: vt_frontend.ajax_url,
                type: 'POST',
                data: {
                    action: 'vt_update_usage',
                    nonce: vt_frontend.nonce
                }
            });
        }
    }
})(jQuery);