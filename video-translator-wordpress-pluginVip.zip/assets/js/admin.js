/**
 * JavaScript الخاص بصفحات الإدارة للإضافة
 */
(function($) {
    'use strict';
    
    // عند جاهزية المستند
    $(document).ready(function() {
        // علامات التبويب
        $('.vt-tab-link').on('click', function() {
            var tabId = $(this).data('tab');
            
            // إزالة الكلاس النشط من جميع الروابط والمحتويات
            $('.vt-tab-link').removeClass('active');
            $('.vt-tab-pane').removeClass('active');
            
            // إضافة الكلاس النشط للرابط والمحتوى المحددين
            $(this).addClass('active');
            $('#' + tabId).addClass('active');
        });
        
        // ===============================
        // صفحة الإعدادات - تنظيف الملفات المؤقتة
        // ===============================
        $('#vt-cleanup-temp').on('click', function() {
            var $button = $(this);
            var $status = $('#vt-cleanup-status');
            
            // تعطيل الزر
            $button.prop('disabled', true);
            
            // تحديث الحالة
            $status.text(vt_admin.lang.cleaning).addClass('vt-status-processing');
            
            // إرسال الطلب
            $.ajax({
                url: vt_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'vt_cleanup_temp_files',
                    nonce: vt_admin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // تحديث حالة النجاح
                        $status.text(response.data.message || vt_admin.lang.clean_completed).removeClass('vt-status-processing').addClass('vt-status-success');
                    } else {
                        // تحديث حالة الخطأ
                        $status.text(response.data.message || vt_admin.lang.error).removeClass('vt-status-processing').addClass('vt-status-error');
                    }
                    
                    // إعادة تفعيل الزر
                    $button.prop('disabled', false);
                },
                error: function() {
                    // تحديث حالة الخطأ
                    $status.text(vt_admin.lang.error).removeClass('vt-status-processing').addClass('vt-status-error');
                    
                    // إعادة تفعيل الزر
                    $button.prop('disabled', false);
                }
            });
        });
        
        // ===============================
        // صفحة معالجة الفيديو - يوتيوب
        // ===============================
        var $youtubeUrl = $('#vt-youtube-url');
        var $youtubeLanguage = $('#vt-youtube-language');
        var $processYoutube = $('#vt-process-youtube');
        var $youtubeStatus = $('#vt-youtube-status');
        var $youtubeResult = $('#vt-youtube-result');
        
        $processYoutube.on('click', function() {
            processYoutubeVideo();
        });
        
        function processYoutubeVideo() {
            // التحقق من صحة الإدخال
            if (!$youtubeUrl.val()) {
                $youtubeStatus.text(vt_admin.lang.invalid_url).addClass('vt-status-error');
                return;
            }
            
            if (!$youtubeLanguage.val()) {
                $youtubeStatus.text(vt_admin.lang.select_language).addClass('vt-status-error');
                return;
            }
            
            // تعطيل الزر
            $processYoutube.prop('disabled', true);
            
            // تحديث الحالة
            $youtubeStatus.text(vt_admin.lang.processing).removeClass('vt-status-error').addClass('vt-status-processing');
            
            // إرسال الطلب
            $.ajax({
                url: vt_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'vt_process_youtube',
                    youtube_url: $youtubeUrl.val(),
                    target_language: $youtubeLanguage.val(),
                    nonce: vt_admin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // تحديث حالة النجاح
                        $youtubeStatus.text(vt_admin.lang.completed).removeClass('vt-status-processing').addClass('vt-status-success');
                        
                        // عرض نتيجة المعالجة
                        var videoHtml = '<video controls><source src="' + response.data.video_url + '" type="video/mp4"></video>';
                        $youtubeResult.find('.vt-video-container').html(videoHtml);
                        $youtubeResult.find('.vt-download-link').attr('href', response.data.video_url).text(vt_admin.lang.download);
                        $youtubeResult.show();
                    } else {
                        // تحديث حالة الخطأ
                        $youtubeStatus.text(response.data.message || vt_admin.lang.error).removeClass('vt-status-processing').addClass('vt-status-error');
                    }
                    
                    // إعادة تفعيل الزر
                    $processYoutube.prop('disabled', false);
                },
                error: function() {
                    // تحديث حالة الخطأ
                    $youtubeStatus.text(vt_admin.lang.error).removeClass('vt-status-processing').addClass('vt-status-error');
                    
                    // إعادة تفعيل الزر
                    $processYoutube.prop('disabled', false);
                }
            });
        }
        
        // ===============================
        // صفحة معالجة الفيديو - تحميل
        // ===============================
        var $uploadButton = $('#vt-upload-video');
        var $uploadLanguage = $('#vt-upload-language');
        var $processUpload = $('#vt-process-upload');
        var $uploadStatus = $('#vt-upload-status');
        var $uploadResult = $('#vt-upload-result');
        var $selectedFile = $('#vt-selected-file');
        var uploadedAttachmentId = 0;
        
        $uploadButton.on('click', function(e) {
            e.preventDefault();
            openMediaLibrary();
        });
        
        $processUpload.on('click', function() {
            processUploadedVideo();
        });
        
        function openMediaLibrary() {
            var mediaUploader = wp.media({
                title: vt_admin.lang.select_file,
                button: {
                    text: vt_admin.lang.select_file
                },
                multiple: false,
                library: {
                    type: 'video'
                }
            });
            
            mediaUploader.on('select', function() {
                var attachment = mediaUploader.state().get('selection').first().toJSON();
                $selectedFile.html(vt_admin.lang.file_selected + ' <strong>' + attachment.filename + '</strong>').addClass('has-file');
                uploadedAttachmentId = attachment.id;
                $processUpload.prop('disabled', false);
            });
            
            mediaUploader.open();
        }
        
        function processUploadedVideo() {
            // التحقق من صحة الإدخال
            if (!uploadedAttachmentId) {
                $uploadStatus.text(vt_admin.lang.no_file).addClass('vt-status-error');
                return;
            }
            
            if (!$uploadLanguage.val()) {
                $uploadStatus.text(vt_admin.lang.select_language).addClass('vt-status-error');
                return;
            }
            
            // تعطيل الزر
            $processUpload.prop('disabled', true);
            
            // تحديث الحالة
            $uploadStatus.text(vt_admin.lang.processing).removeClass('vt-status-error').addClass('vt-status-processing');
            
            // إرسال الطلب
            $.ajax({
                url: vt_admin.ajax_url,
                type: 'POST',
                data: {
                    action: 'vt_process_uploaded_video',
                    attachment_id: uploadedAttachmentId,
                    target_language: $uploadLanguage.val(),
                    nonce: vt_admin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // تحديث حالة النجاح
                        $uploadStatus.text(vt_admin.lang.completed).removeClass('vt-status-processing').addClass('vt-status-success');
                        
                        // عرض نتيجة المعالجة
                        var videoHtml = '<video controls><source src="' + response.data.video_url + '" type="video/mp4"></video>';
                        $uploadResult.find('.vt-video-container').html(videoHtml);
                        $uploadResult.find('.vt-download-link').attr('href', response.data.video_url).text(vt_admin.lang.download);
                        $uploadResult.show();
                    } else {
                        // تحديث حالة الخطأ
                        $uploadStatus.text(response.data.message || vt_admin.lang.error).removeClass('vt-status-processing').addClass('vt-status-error');
                    }
                    
                    // إعادة تفعيل الزر
                    $processUpload.prop('disabled', false);
                },
                error: function() {
                    // تحديث حالة الخطأ
                    $uploadStatus.text(vt_admin.lang.error).removeClass('vt-status-processing').addClass('vt-status-error');
                    
                    // إعادة تفعيل الزر
                    $processUpload.prop('disabled', false);
                }
            });
        }
    });
    
})(jQuery);